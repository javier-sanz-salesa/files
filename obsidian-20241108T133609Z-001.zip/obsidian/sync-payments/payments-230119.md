- Tengo el bug del parallelStream asignado
- Lo de los dotfiles ya lo mencionamos en la sync y no lo mantenemos
	- Quedamos en que van a intentar hacer cambios en el proyecto original y promocionar la herramienta entre los demás equipos
- Preguntar por lo de la nueva instancia de Mambú
	- Hecho y probado
- Recordar lo de la retención de los topics
	- Dice Juanma que se va a poner con ello




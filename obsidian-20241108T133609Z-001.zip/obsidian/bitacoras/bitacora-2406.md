## 03/06/2024

- ✅ Completados cursos de formación de Orange (ciberseguridad y código ético)
- ✅ Leído el ADR de elección de la herramienta SAST y sugerido que nos convoque a reunión
- #DPA-2091: DLQ and recovery topics using avro spec
	- Comienzo a mirar los componentes de nuestro error handling
- ⚡ Me pongo a mirar el problema que ha descrito Jose Manuel sobre los id de idempotencia, key de los mensajes, etc
	- Decidimos que, para mensajes que comparten el mismo topic, deben tener una key formada por lo que necesiten **Y** el tipo del evento (algo parecido al nombre de la clase, diría yo)
	- DL necesitan el "nombre de la tabla" y el "idempotence key" porque están usando un modelo de "domain events" como un event sourcing.
		- Por lo tanto tienen que saber que varios eventos se refieren a la misma "entidad"
		- Y además deben saber cuál es la clave primaria de dicha entidad
		- ...
		- Sabiendo esto, vamos a pensar en soluciones
			- Deberían implementarlo ellos. O una pieza previa a ellos, para ser correctos.
			- Ahora mismo nosotros metemos datos en los eventos para que ellos lo hagan de forma "automática", pero me da que esto no es muy correcto porque el que crea el evento no sabe muy bien por qué lo hace.
- R: ⚡Platform setup
	- Necesito repasar qué es lo que necesita un equipo para ponerse a trabajar en backend (equipo de backend)
- R: Kick Off: Bambu MVP Setup
	- No recuerdo ni de qué hemos hablado

## 04/06/2024

- R: Escoger SAST
	- Vamos a escoger sonarqube y vamos a proponer snyk para más adelante
- R: Temas de Avro
	- Resultado: Reunión con ellos
	- Duda: Necesitamos un partitionId? Yo creo que sencillamente hay topics que no podemos compactar
- Mirando temas del SerDe de schema registry + cloud events
	- Lo que hay podría funcionar
		- Yo diría que no es necesario por lo que he dicho antes sobre la compactación
			- TODO: Mirar esto y ver si realmente no es necesario compactar
				- ✅ Mi punto es que no es necesario introducir más campos.
				- La key sirve para...
					- Escoger una partición --> Estos eventos han de consumirse en orden
					- Escoger cómo vamos a compactar el topic --> si es que vamos a compactar
						- Porque a lo mejor lo que hay que hacer es emitir SNAPSHOTS periódicamente cuando los topics crezcan, no confiar en la compactación
				- *Podríamos* proporcionar un `idempotenceId` en una cabecera. Esto ayudaría al DL a decidir sobre qué fila tienen que hacer un upsert sin tener que montar ellos el consumo diferente para cada topic
					- También puede haber otras soluciones
- Con Santi viendo a ver qué tarea se coge
	- La de los topics de DLQ?
	- Creo que se va a coger lo del CustomReflectData

## 05/06/2024

- #DPA-2091 
	- Dejo la tarea, porque me voy a poner con la de los tests de integración y aceptación en local con schema registry
- #DPA-2093: WoW locally using avro: integration and acceptance tests
	- Me pongo con ello
- R: Hablamos con la gente de data para estar en la misma foto sobre las cabeceras del SR
	- Rechazamos en principio la posibilidad de añadir una cabecera con el localTime
	- Vemos que las cabeceras que ellos necesitan son el "tableName" y el "idempotenceId"
		- ¿El idempotenceId necesita el tipo de evento? Entiendo que si (no me queda 100% claro)
	- Mencionamos que es muy posible que haya una primera versión de la plataforma funcionando as-is
	- Por lo demás ok
- R: Entre nosotros viendo next steps
	- Me sigue sin quedar claro el tema de que sea necesario añadir un partitionId, aunque no consigo que nadie me haga caso
	- Decido ponerme con el tema de los tests en local con schema registry, etc
- R: IT Sync
	- convention-tests
		- banking (David): OK
		- cuentas (Jorge): OK
		- arturo (ACDC): OK
		- yair (paycards): nada
		- javi casado (credit): OK

## 06/06/2024

- #DPA-2093 
	- Sobrescribo los cambios del kafka-tile desde la rama a master. Pruebo
	- Actualizo versión

## 07/06/2024

- #DPA-2093 
	- El test falla al comprobar si los topics existen
	- Compruebo que la creación de topics aparentemente no da problemas
	- Hay que comprobar si es la comprobación de que esos topics existen la que da problemas
	- Todo funciona si introduzco una pequeña pausa desde que creamos los topics hasta la verificación de los mismos
		- Da igual que cuando creemos los topics hagamos un `all().get()`.
		- No encuentro configuraciones que puedan estar afectando este retardo
		- ⚡TODO: Hablar con Javi sobre este tema
			- Quizá debería mirar algunas de las propiedades que están en el tile para one bank, que tienen buena pinta
			- Pruebo las propiedades `KAFKA_CFG_TRANSACTION_STATE_LOG_REPLICATION_FACTOR`, `KAFKA_CFG_TRANSACTION_STATE_LOG_MIN_ISR` y `KAFKA_CFG_GROUP_INITIAL_REBALANCE_DELAY_MS` pero no funcionan

==========

## 10/06/2024

- Tema de siguientes candidatos en ir saliendo
- R: Weekly con infra
- Me junto con Carlos para explicarle la tarea de la DLQ
- #DPA-2093 
	- Pruebo con la imagen de Apache Kafka en vez de Bitnami (nada)
	- Hablo con David y me dice que no se había encontrado con este pero que el `TopicCreator` ya sólo se va a utilizar para los tests
	- Pruebo a hacer que el `TopicCreator` y el `EventTopicVerifier` se ejecuten en secuencia (sólo un listener del `ApplicationStartedEvent`) --> No funciona
	- Siguiente: Implementar el bucle de espera
		- Lo implemento y funciona
	- Me pongo a implementar tests unitarios para el creador de topics y no soy capaz de hacerlo de forma sencilla
	- Le meto algo de refactor a la rama
		- No consigo construirla porque me falla el Sonar en algo no relacionado(-> https://sonar-backend.devtools.proyecto-sol.es/project/issues?resolved=false&types=VULNERABILITY&branch=hotfix%2FDPA-2093_multiple_topic_verification_attempts&id=com.orangebank.boot%3Aorangebank-boot&open=AZAD1ZC84gwQ4cHARyU_)

## 11/06/2024

- #DPA-2093 
	- Marco la issue como resuelta y lanzo la build de nuevo
		- Falla por timeout del nexus
		- Falla porque he sacado mal la rama. Hay que sacarla desde SNAPSHOT
			- Javi va a mergear esta rama con la suya para poder sacar versión. Él se encarga
	- Genero la `3.0.0.23` del tile de Kafka. Simplemente con las versiones subidas de Kafka y eliminando zookeeper
	- Estoy un rato mirando las imagenes que hay (confluent, bitnami y apicurio)
		- La de confluent es grandísima (1,5 GB). Está llena de morralla
		- La de bitnami es lo mismo pero más ligera
		- ApiCurio es bastante más ligera pero es otra cosa
	- Dice Jose de usar ApiCurio, que ya está funcionando, salvo que habrá que poner la versión "kafkasql"
		- No, porque estamos en local y esto es para poner en el tile
	- Hago los cambios para añadir el registry de apicurio
		- DOCKER> I/O Error [Unable to start container id [320059c917c4] : {"message":"driver failed programming external connectivity on endpoint apicurio-registry-mem-2 (fcf9b6e142c76df3a4f29ec37d61213dbce5b0a9bd03aa47a7e3dd9312cd0c27): Bind for 0.0.0.0:8082 failed: port is already allocated"} (Internal Server Error: 500)]

## 13/06/2024

- Cambiada en el tablón la etiqueta "maple" por "ebro"
- Intento hacer que el topic creator y el topic verifier no se carguen los dos a la vez
	- No lo consigo y lo intento de varias formas
- Decido cambiar lo del patrón de los topics
	- Tampoco lo llego a conseguir

## 14/06/2024

- R: Weekly
	- Cambio de nomenclatura para topics de dlq y recovery -> Seguimos con ello pero no vamos a meter el verifier (sólo el creator, que funcionará para los tests). La opción es inhabilitar el verifier de ob-boot cuando esté el de ebro
		- De todos modos el verifier va a tener en cuenta los topics de recovery y dlt viejos
	- Dead letter: Pinta que vamos a escribir en binario (sin esquema) -> Lo está mirando Carlos
	- auto-offset-reset: No llegamos a un acuerdo (yo digo que mejor forzar a que los equipos lo definan) porque es un pollo
	- tema de formato de avsc (santi): No hay referencias entre avsc's. No llegamos a nada en cuanto a 'namespaces' internos de la clase o al uso de "java-class"
		- Luego hablo con Santi y creo que comprende mi idea
- Cambio el `TopicTemplate` y sus tests (integración y unitarios)
	- Lo hago "compatible" con el formato antiguo. De tal modo que detecta estos topics y no les crea una dlq y un rec encima.
	- No me pasan los tests, entiendo que por algún problema de lo que están haciendo otros

==========

## 17/06/2024

- R: Weekly con infra
	- Tema de no hacer que seguridad tenga que aprobar las PR de petición de secretos
- #DPA-2114
	- Arreglo en local el problema por el cual el error handler no arrancaba, que es tema de Carlos (ya me bajaré la solución buena cuando él la suba)
	- Elimino el TopicVerifier
	- Investigo para evitar que se carguen los dos a la vez
		- El topic creator no salta seguramente debido a que a por property
		- Hay un test de integración que seguramente habrá que tocar
		- Pinta a que tenemos que meter `@Primary`

## 18/06/2024

- #DPA-2114 
	- La termino

## 19/06/2024

- Chapter
	- Hablar con Eduardo González el tema de su salida
- R: Setup funcional
	- Javi nos pasa un excel con todas las llamadas y eventos que lanza la contratación de un domex
	- Jose: Usar microcks para el mock de Mambú
		- ok
	- Jose: No subimos tecnología. Lo que hay ahora
		- Cambio de paquetería
- #DPA-2093 
	- Dicho en la daily: Hay que cambiar los `docker-compose.yml` para que utilicen un setup lo más parecido posible al tile
	- TODO: ⚡ Hay que mirar si el comportamiento esperado es que entre restarts del docker compose los topics se guarden
		- No parece que esto sea un problema si se hace `docker-compose down`
	- Cambio los `docker-compose.yml` y pruebo que se pasan los tests de integración en local
	- Cambio el `README.md` del tile y genero la versión `3.0.0`
		- Hago que `revolving-loans-reporter` utilice dicha versión
	- ⚡ Doy la tarea por terminada a falta de ver si es necesario documentar, como dijo Jose Manuel por el chat

## 20/06/2024

- Documentar lo que sea necesario en la guía del desarrollador los tests de integración y tests de aceptación
	- ✅ He creado la sección en Confluence con lo que había en el `README.md`
	- ✅ He creado una guía de mantenimiento en el `README.md`
- Le doy una vuelta a todo el asunto relacionado con los chapters y lo escribo
	- Le escribo a Joaquín para ver si le podemos dar una vuelta mañana (o cuando pueda)

## 21/06/2024

- No apunto nada

==========

## 24/06/2024

- Hoy (plan):
	- Reunión con Joaquín para hablar de temas del chapter
	- Ver lo que ha hecho Carlos con la DLQ y comprenderlo
		- En base a esto decido y me marco un objetivo para hoy con la tarea que sea
- Hoy (real):
	- Comprensión de lo que se está haciendo con las DLQ
	- Echar un vistazo a cómo funciona el `reprocess-event-batch`
		- Es un batch normal que hace un bucle de consumo en el DLQ y producción en el recovery
		- Consume y lo convierte en un `EventJournal<RawEventJournalPayload>`. Luego produce ese mismo evento.
	- Echar un vistazo a lo del `SeekAware`
		- Algunos listeners en los servicios implementan `EventJournalConsumerSeekAware`
			- feed, people, voice-of-customers (¿?) y transactions
			- Yo diría que sí que se está usando. Aunque sea de forma un tanto marginal
			- No afecta a `reprocess-event-batch`
	- R: Temas del chapter
		- ⚡ Crear una página de Confluence para los temas de organización
		- ✅ Hecho! (a ver si Joaquín le echa un ojo y le da continuidad)
	- R: Weekly con infra

## 25/06/2024

- Hoy (plan)
	- Acabar con el `reprocess-event-batch`
- Hoy (real)
	- ✅ Doy permisos admin a todos nosotros en nuestro espacio de Confluence
	- Quizá

## 26/06/2024

- Tema de las dependencias
	- iCal4j?
- R: CLI MAPLE
	- xxx

==========
## Pendientes

- Tema #DPA-1664 
	- ⚡ Ir implantando lo de los convention tests
- ⚡:  Hablar con Diego para mover el tema este de documentar Mambú, sus painpoints, sus incidencias...

## Seguimiento

- ⚡ Tema de los permisos en confluence
	- 📆 El **4 de Abril** vuelve Julián de vacaciones. Seguimos empujando con esto
	- El 9 de Abril vuelvo a preguntar en el chat
- ⚡ Mejoras en el way of working
	- Hablar con Ivan

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
	- En caso de que el proyecto tenga continuidad asegurada
- 💡♨️ Dar pasos hacia el continuous deployment
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY
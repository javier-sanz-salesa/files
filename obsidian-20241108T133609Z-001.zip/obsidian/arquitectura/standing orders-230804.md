#standing-orders
## Análisis de feature "standing orders" para payments

- Servicio sto -> standing-orders
	- ok
- Discutir la utilidad de tener diferentes bff's
	- De momento lo metemos en transfers-bff
- Entiendo que entre que maneje las standing orders Mambú y que lo hagamos nosotros hemos elegido la segunda opción. ¿Por qué?
	- ¿No se puede configurar el streaming api para que te devuelva ciertos campos que tú le has proporcionado?
	- El motivo es que hay intención de añadir standing orders como transferencias instantáneas y como bizum. Y esas estarían fuera de Mambú
- Relación entre transfer y standing order
	- De algún modo no me gusta que la información de las ejecuciones de una standing order esté dentro de transfers
	- standing-orders va a escuchar eventos y a replicar la información en su propia base de datos
- ¿Qué necesita validar standing-orders con transfers-validator?
	- ¿No puede estar esta lógica dentro de standing-orders?
	- Es lógica compleja que depende de otros dominios
- Cambiar el orden de "init SCA flow" con el cambio de estado a RECEIVED para asegurarnos que siempre tenemos el estado a RECEIVED antes que AUTHORIZED
	- Les hablo de la librería de obboot-state-machine
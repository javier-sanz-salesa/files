## 06/05/2024

- ✅ Curso de Data Science
- ✅ Acceso a los vídeos de las formaciones
	- ⭕ Falta que Nico me de acceso al vídeo cuya grabación tiene él (hecho)
- #DPA-2046 
	- Deshabilito los tests de aceptación porque no voy de momento a modificar el tile de Kafka con Schema Registry
	- ✅ Descubro un problema con la configuración y lo arreglo
	- ✅ Consigo desplegar el servicio, pasar SonarQube
	- ✅ Ejecuto el batch correctamente, pero como no obtiene nada del servicio rest al que está llamando, no intenta emitir eventos
	- 🚫 Tengo aún que configurar la URL del Schema Registry en el -ops, pero voy a esperar que falle

## 07/05/2024

- #DPA-2046 
	- Voy a personalizar el batch para devolver datos cocinados cuando hace la llamada rest
		- No hace falta porque el batch tiene 2 parámetros que permiten controlar exactamente qué va en el mensaje que vamos a enviar
	- Consigo que envíe el evento y falle. Cosas por hacer
		- 🚫 Añadir la URL del schema registry
			- Lo añado pero falla al tratar de comunicarse con el schema registry, que está en `http://poc-schema-registry.platform-global-services.svc.cluster.local:8081`
				- Mensaje de error: `org.apache.kafka.common.errors.SerializationException: Error serializing Avro message`. cause: `Caused by: java.net.SocketException: Connection reset`
				- Estoy bloqueado
					- Dice Jose que hay que abrir puertos
					- Dice Santi que debería llegar (creo que no, que Jose tiene razón)
					- Pregunto a Morgan pero parece que justo ya no anda por aquí
		- ✅ Crear el topic
			- Parece que ya está. Lo he puesto tanto en el productor como en el consumidor
		- 🚫 Registrar el esquema (no he llegado aún a ello)
- Tema de la lista de nombres

## 08/05/2024

- #DPA-2046 
	- ✅ Problemas de acceso: Connection Reset
		- Los contenedores, por defecto, abren el puerto 8080. Cambio los puertos del schema registry para que exponga el 8080
	- 🚫 Error RestClientException: Error; error code: 50005
		- Investigo y esto es debido a que ahora da un `502: Bad Gateway`, que el cliente intenta parsear como JSON y falla con ese error

## 09/05/2024

- Curso de Python
	- ✅ Muevo la grabación
- Tickets para dar de baja a los usuarios que salen del proyecto en Mayo
	- ✅ Además hago limpieza del canal Backend
- #DPA-2046 
	- Voy a hacer doble túnel al pod de istio-shell a ver si saco algo en claro
	- Al final el problema es que el service al que estoy llamando mapea el puerto 80 al 8080, así que la llamada la tengo que hacer al puerto 80
	- ✅ Todo funciona!
- R: Wishlist

==========

## 13/05/2024

- Tema de plataforma Maple, prioridades, etc
	- R: Con el equipo. Repasando lista de tareas
	- R: Con los de infra
- #DPA-2046 
	- Probando el plugin de `io.confluent.kafka-schema-registry-maven-plugin`
		- Metas que nos interesan
			- `schema-registry:test-compatibility`
			- `schema-registry:validate`
			- `schema-registry:register`
		- ✅ Documentado en https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/4180279492/Lifecycle+Working+with+Schema+Registry

## 14/05/2024

- #DPA-2046
	- Dejo los cambios en el consumer ya preparados

## 16/05/2024

- xxx

==========

## 20/05/2024

- ✅ Convocatoria de reunión para hablar del tema de Mambú
- Revisar la página de Confluence que requiere nuestro input con documentación a ver si me puedo encargar de algo
	- ✅ Añado la parte del schema registry y me pongo como responsable
- ✅ Ayudando a Sergio con el problema de ejecutar los convention tests en los servicios que no tienen kafka
- ✅ Documentación de los convention-tests

## 21/05/2024

- ✅ Soporte a Sergio con el tema de la dependencia con `javax.ws`
- Último día curso de data science
	- ✅Vídeo movido, renombrado y descargado
- ✅ Ayuda a Ivan con el tema del servicio de backend de lo del CLI

## 22/05/2024

- R: IT Sync
- R: Planificación de tareas ob-boot 2.17 y 3
	- Javi no necesita nuestra ayuda salvo quizá para ayudarle a hacer las pruebas
	- Haremos la release y podemos hacer que los equipos vayan subiendo de versión
	- Javi: Yo voy a preparar la reunión sobre Mambú, etc
		- Me voy a poner a mirar/repasar el dominio de credit
	- David: Va a ver si podemos quitarnos los Makefiles y los docker-compose.yml
	- Santi: Dudas con temas de velocidad de la build
		- No es tema de potencia de máquinas
		- Se puede paralelizar la build
		- (ob-boot) se pueden sacar cosas de ob-boot, incluso todo
		- (proyectos) habría que hacer algo con los acceptance-tests
- Estudiando dependencias de Mambú en Loans (no revolving)
	- Casi todo menos `loans-adapter`

## 24/05/2024

- R: Weekly
	- #DPA-2046 Next steps
		- Jose Manuel: Va a repasar las opciones para funcionar con avro desde el punto de vista del desarrollador (partir de asyncapi, usar el `CustomReflectData`, picarse los esquemas a pelo en avsc o avdl)
		- David: Va a comenzar a documentar la parte de la guía del desarrollador referente al uso de Kafka. Hablará conmigo con respecto a las partes de compatibilidad del esquema, etc
		- Yo: Voy a ver las implicaciones del esquema con las DLQ, topics de recovery y el `reprocess-event-batch`
		- Santi, Carlos: Se pondrán al día cuando puedan
	- Tema de las dependencias con Mambú
		- Tengo que hablar con Joaquín para:
			- Asegurarnos que Diego hace un documento con los pain points de Mambú (incluyendo incidentes, etc)
				- Si hace falta esto puedo moverlo yo
			- Estas carencias podrían ir a parar al contrato que se firme con ellos
			- Esto tendrían que saberlo en Maple a fin de que se haga o no un plan para desarrollar nuestro propio core (total, no somos un banco ahora mismo)
			- Hay gente que va a estar "ociosa" y podríamos emplearla a este fin
- Ayudo a David a mover algunas páginas al espacio de Bambú
- R: Con Joaquín
	- TODO ⚡:  Hablar con Diego para mover el tema este de documentar Mambú
- Subida de versión arq
	- Subido `campaign-vendors-processor-batch`. Todo OK. Hay que sacar release también del starter de crypto

==========
## 27/05/2024

- Subida de versión arq
	- ✅ `loans-adapter`
	- ✅ `loans-batches`
	- 🚫 `loans-monthly-statement-batch`
		- No puedo construirlo porque no tengo acceso a la dependencia `loans-statements-reports`
	- 🚫 `loans-statements-reports`
		- Intentando que los tests de integración funcionen
			- No debería ser un módulo de proyecto, quizá un starter o similar
			- Ni siquiera eso!! Debería estar la lógica de cada método en cada servicio de los 2 que dependen de él
				- TODO ⚡: Hablar esto con Jose
- R: Daily
	- David: Temas sobre la organización de la documentación
	- Joaquín: Temas sobre el contrato con Maple
	- Carlos: Tema de transpaso de los datos a Cetelem, Servinform
- R: Mambú MVP Setup
	- Temas de ubicación y formato de la documentación
	- Tema de nombre de la plataforma: EBRO!!
- Diego envía un resumen con todo lo de Mambú
	- TODO ⚡: Hablar esto con Javi, con Diego

## 28/05/2024

- Sigo probando con la nueva versión de arquitectura (spring 2.17 aún)
	- Jose dice que lo de `loans-statements-reports` está bien así. Yo no estoy de acuerdo pero de momento lo voy a dejar estar 🤷
	- Javi saca una nueva versión de la librería: 2.16.1.1072
	- Algunas versiones comunes que hay que subir
		- `orangebank-boot-dictionary`: 2.13.1.75
		- `orangebank-boot-starter-cbs-client`: 3.14.1.114
		- `orangebank-boot-starter-reports`: 1.17.1.78
	- `loans-notifications-batch`
	- `loans-onboarding`
	- `loans-products`
	- `loans-promotions-batch`
		- Tiene una dependencia con `robinson-list-app`  que está en `loans-promotions`
- Con Santi explicando lo del schema registry

- Miercoles 5 -> pruebas cancelación masiva en PRE
- Lunes 3 -> Expulsión de los clientes 0, 0

## 31/05/2024

- R: Daily larga (+weekly)
	- Hablamos sobre el ADR que está haciendo Jose Manuel sobre las cabeceras planeadas para los eventos siguiendo la especificación de Cloud Events
	- Movemos toda la documentación relacionada con el uso de Schema Registry en la nueva plataforma al espacio de Confluence de la nueva plataforma (espacio BAMBU)
- R: Seguimos trabajando sobre la nueva arquitectura de eventos
	- XXX

==========
## Pendientes

- ❗❗ Darle continuidad a lo del schema registry y a lo del OpenAPI
	- En caso de que el proyecto tenga la continuidad asegurada
	- La PoC en local ya está hecha. Merece la pena una PoC en DEV?
		- Consiste en desplegar un schema registry "de estraperlo" como un microservicio y desplegar la PoC. ¿Merece la pena?
	- Ya está enviada la convocatoria para el Lunes 15
		- Ideas con qué continuar añadidas a la convocatoria de la reunión
- Tema #DPA-1664 
	- ⚡ Ir implantando lo de los convention tests
- ⚡:  Hablar con Diego para mover el tema este de documentar Mambú, sus painpoints, sus incidencias...

## Seguimiento

- ⚡ Tema de los permisos en confluence
	- 📆 El **4 de Abril** vuelve Julián de vacaciones. Seguimos empujando con esto
	- El 9 de Abril vuelvo a preguntar en el chat
- Tema #DPA-1966 
	- ⭕ A la espera de que Diego Almazán convoque una reunión con los afectados (hay que migrarlo antes del freeze de verano)
	- 📆 La fecha de decomisionado de los entornos pasa a ser el **1 de Septiembre**. Hemos de comunicarlo si terminamos antes.
	- 📅 Se atrasa esto a Q1 de 2025
- ⚡ Mejoras en el way of working
	- Nico va a hablar con Carmina sobre nombrar responsable de todo esto a Ivan Morales
	- Cuando nos de el OK hay que juntarse con él para hablarle de todo lo que hemos pensado al respecto

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
	- En caso de que el proyecto tenga continuidad asegurada
- 💡♨️ Dar pasos hacia el continuous deployment
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY
## XX/XX/XX

- Tema del starter de paycomet --> https://sonar-development.devtools.proyecto-sol.es/project/issues?id=com.orangebank.orangebank-boot-paycomet%3Aorangebank-boot-paycomet&issues=AYXKyiuzc5eLg2LEFuhD&open=AYXKyiuzc5eLg2LEFuhD
	- com.orangebank.paycomet.adapter.tpv.PaycometServiceImpl#convertAmountToPaycometAmount
## Propuesta

Responsabilidades

- Las personas
	- Tener una foto del estado del proyecto en cuanto a personas
		- Hacer reuniones 1 on 1 con los TL (pensar en la periodicidad)
	- Evaluaciones?
		- De momento no y si es necesario ya me avisarán
	- Algo particular con los que son internos?
		- Formación, eventos, etc
			- En principio no hay presupuesto y no es mi tarea (sin embargo yo a medio plazo sí que intentaré mover estos temas)
- Los equipos
	- Retrospectivas. 
		- Hay que estar en todas y también en las reviews
	- Reunión con los TL
		- De momento no sabemos. Lo dejo para más adelante
	- IT Sync
		- Asistir a todas que son los miércoles semanalmente
- Onboarding y contratación (y offboarding)
	- Preparar un onboarding para cualquier persona que entre en el equipo
		- Si. Tengo la lista de pasos
	- Habrá que cubrir bajas. ¿Con externos? Entiendo que contratar internos de momento no
		- ¿Qué proceso de selección se sigue aquí?
			- Ya hay una prueba técnica que la está corrigiendo otra gente
			- Tendría que meterme en esto. También quiero revisarla yo a ver qué se le puede añadir o restar
- Divulgación y formación
	- Sección de confluence
		- Tengo que ir a nuestra sección en confluence, leer lo que hay, organizarlo, hacer limpieza, decidir el formato e ir añadiendo lo que sea necesario
			- Elegir los temas de los que se quiera promover buenas prácticas
	- Reuniones del chapter
		- Lo iban a promover. Asistiré cuando me inviten
	- Canal de Teams
		- Tengo la lista de personas. Hay que crearlo con todo el mundo. Antes debería hablar con los TLs y "presentarme"
- Otros
	- Debería juntarme con la gente de Agile a ver cómo podemos ayudarnos mutuamente y ver si necesita algo de mi.
	- Hay que promover el tema de los champion roles: decidir cuáles son, cómo van a funcionar y demás.

Dudas
- A quién reporto y cada cuánto?
- Hay reunión con otros chapters? y con la gente de Agile?
- Relación de arquitectura con todo esto

Medidas de ASAP
- Canal en Teams
- Presentarse a los TLs
- Tema de los champion roles


## Medidas TO-DO

- Reunirme con la gente de Agile (=David)
	- Hecho
- Repasar y documentar el tema de los champion roles
	- Hecho
- Hacer reuniones con los TL (ya convocadas)
	- Hecho
- Meter tareas arquitectura en base a lo que hemos hablado
	- Hecho
- Crear el canal "Backend Chapter" con toda la peña
	- Hecho
- Repasar y documentar el onboarding
	- Hecho


## Medidas a hacer

- Ir convocando las 1 on 1
- Repaso al repositorio de chapter backend
- Mover lo del CD
- Tareas de arquitectura
	- Incidencias (temas con el sftp sync batch, traceRequest en el finally)
	- Mejoras de calidad de vida (visualizar transacciones en el APM de Kibana para la ejecución de batches)
	- Perseguir con los equipos la inclusión de `orangebank-boot-documentation`
	- Renaming de la arquitectura
	- Upgrades de versión (java, spring security, spring , archunit)
		- Soporte en formación y documentación
	- Generación de código a partir de la especificación
		- Asyncapi, Openapi
	- Añadir MapStruct
	- Trazas de negocio?¿
	- Candidatas:
		- Tema de `traceRequest` en el `finally`
		- Tema del tracing APM en los batches
		- Echar una mano a Jose con los generadores de documentación
- Determinar una lista de temas de buenas prácticas y elegir cómo promoverlo entre los equipos, etc
- Irse reuniendo con los equipos (1 on 1)
- Ver lo que hay en https://bitbucket.org/obkesp/workspace/projects/CHBCK
- Continuous deployment
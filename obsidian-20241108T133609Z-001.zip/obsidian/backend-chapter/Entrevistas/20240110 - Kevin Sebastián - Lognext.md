Es un perfil con 4 años de experiencia entre desarrollo clásico full stack y arquitectura de microservicios más bien síncrona con bases de datos no relacionales y cierto uso de kafka

## Impresiones

Se pone bastante nervioso y se pone a divagar sobre cosas que no aportan nada. Da la sensación de que no tiene claros los conceptos o no consigue explicarlos dada la presión. En principio pienso en descartarlo pero tiene ciertos conocimientos en temas de arquitectura hexagonal y kafka que le hacen interesante. Habrá que comparar con el resto de candidatos

Mi impresión es que es un perfil junior/medio que puede tener sentido dependiendo de la tarifa.

## Preguntas en entrevista técnica

### ¿Qué es un microservicio en el contexto de una arquitectura de microservicios? (Arquitectura, Básico)

"Es un servicio pequeño". No sabe decirme muy bien qué características tiene

### ¿Qué anotación de Spring Boot usas para crear un servicio REST? (Spring, Básico)

bien

### ¿Cómo se verifica una condición en una prueba unitaria con JUnit? (Testing, Básico)

bien 

### ¿Cómo se crea un nuevo repositorio Git? (Herramientas, Básico)

bien

### Explica el concepto de particiones en un topic de Kafka y su importancia. (Kafka, Medio)

bien

### ¿Cuál es la diferencia entre los métodos HTTP PATCH y PUT? (API REST, Medio)

sabe que los dos se utilizan para realizar modificaciones pero no sabe decirme exactamente en qué

### ¿Cómo se inyecta un bean en Spring Boot usando @Autowired? (Spring, Medio)

Sabe decirmelo pero tengo que guiarle mucho. No entiende demasiado bien los conceptos

### ¿Qué es la arquitectura hexagonal y cuál es su principal objetivo? (Arquitectura, Básico)

Lo sabe bastante bien

### ¿Qué es un consumidor en Kafka y para qué se utiliza? (Kafka, Medio)

Lo sabe bastante bien, conseguimos hablar de idempotencia y no lo hace demasiado mal
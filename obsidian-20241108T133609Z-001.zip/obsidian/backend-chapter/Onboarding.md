- Partes comunes
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/891912227/Pre-onboarding
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/892043265/General+Onboarding+Process
- Accesos (ha de hacerse la semana de antes)
	- Verificar que tenemos la cuenta @orangebank.es
	- Atlassian: Jira, Confluence, Bitbucket
		- se pide por MyAccess (https://myaccess.microsoft.com/@orangebankes.onmicrosoft.com#/access-packages/active/) (hay dos paquetes, que si se buscan por la palabra "Atlassian" sirven para Jira y para Confluence, y en el detalle de la petición se debe solicitar las url's de los espacios a los que se pide acceso y si es necesario lectura/escritura
	- Teams
		- se pide por HelpDesk: https://obkesp.atlassian.net/servicedesk/customer/portal/2/group/11
		- Canales: Backend, pregunta en tu squad
	- Correo ->> Outlook
	- Forticlient VPN
		- https://obkesp.atlassian.net/wiki/spaces/DS/pages/3522068485/Requirements+for+VPN+Connection+and+required+certificates
	- Credenciales AWS / MFA
		- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/3726311494/MFA+Authentication
- Entorno
	- https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/41943051/Development+environment+setup
- Formación
	- Sharepoint: Backend_Technical_Sessions_Doc y los videos
	- Release train, Sharepoint: CICD and pipeline
	- https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/3826319364/Overall+Architecture
	- https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/3231154257/Backend+Architecture




Trasladar todo esto a "development"¿?
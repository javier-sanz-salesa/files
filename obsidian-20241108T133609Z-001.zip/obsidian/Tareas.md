- synchronizer
- repo del playwright ¿?
	- test de api con playwright
	- lanzar los tests de playwright dsde jenkins
- onboarding - playwright - verificación de email
- página con todos los frontales. Usuarios y contraseñas

## Ideas - Automator

- Caso de uso ejemplo (esto me lo estoy inventando yo)
	- Se preparan unos datos
	- Se configuran ciertos mocks de un third party
	
	- Se rellena un formulario en el frontend
	- Se pulsa un botón
	- Se recoge una respuesta en el API
		- DUDA: ¿Cómo se sabe que ciertos third parties han de ser simulados mediante un mock?

	- Se espera la recepción de ciertos eventos
	- Se comprueba el estado de ciertos registros en bases de datos

- Estamos mezclando ideas
	- Filosofía de tests (cuándo hacemos qué tests y cuándo lo ejecutamos)
	- ¿Cómo vamos a hacer lo que queremos hacer? (test e2e ejecutables en bulk o mediante selección)
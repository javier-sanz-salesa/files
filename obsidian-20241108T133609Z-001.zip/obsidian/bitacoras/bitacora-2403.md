## 01/03/2024

- Weekly
	- #DPA-1733 
		- David sugiere el uso de RedPanda como UI para Kafka / SR, etc
		- Discusión acerca de modos de compatibilidad
			- Es preferible FULL_TRANSITIVE a BACKWARD_TRANSITIVE?
			- Nos da realmente más flexibilidad a la hora de que los equipos desplieguen?
			- ¿Cómo puede hacerse la distribución de los esquemas y cómo afecta en esto el modo de compatibilidad? (TODO)
				- Básico: Los .avsc están tanto en productores como en consumidores
				- Usar el plugin de maven de schema-registry?
			- schema normalization!
		- Hago un estudio sobre modos de compatibilidad y todo me vuelve a llevar a BACKWARD_TRANSITIVE
			- Lo pongo en el canal, a ver si alguien se anima
- Tema framework e2e
	- Le paso a Andrei documentación, etc
	- Me dice que no tiene tareas y que tiene que confirmarle alguien
	- Me dice Nico que haga pair programming o algo
	- Le cuento lo de Jose y ya hablaremos el Lunes

==========

## 04/03/2024

- Reuniones de bienvenida de Julio
	- Ayudar con las pedidas de permisos
	- Dirigirle a la documentación que se puede ir leyendo (pedir que nos avise si hay cosas que se pueden mejorar)
	- No olvidarse de convocar el checkpoint de la semana que viene
	- Reiterar que me puede contactar por teams para lo que sea
	- Reunión con Yair / David
- #DPA-1733 
	- Añado a la documentación del spike la investigación en modos de compatibilidad que hice el viernes
	- Añado el código fuente
- Tema de qué se está pidiendo en el recruiting (heh)
	- Creo una nueva página (no merece la pena copiar la que ya hay y además no tengo permisos) -->> https://obkesp.atlassian.net/wiki/spaces/DEV/pages/4068540464/Developer+s+requirements
	- Enmarrono a los demás (a ver si alguien me hace puto caso)
		- Ivan de QA no me ha entendido bien
		- Ivan de front web ha actualizado la info
		- Morgan ha puesto temas de seguridad
		- Front mobile han pasado de mi
		- Chudo me ha pasado un enlace para que curre yo
		- Javi Almodóvar ha añadido lo del equipo de data

## 05/03/2024

- #DPA-1733 
	- Cambiando la estrategia de nombrado de subjects para admitir múltiples eventos a través del mismo topic
		- Hecho y añadido a la PoC
	- Documentandome acerca de la normalización de esquemas
		- Ahora mismo productor y consumidor
		- En nuevas versiones, a través de la configuración global

## 06/03/2024

## 07/03/2024

- Reviso el estado de las tareas de eliminación de endpoints de Mambú

## 08/03/2024

- Weekly
	- Estuvimos hablando de lo que ha hecho Jose con langchain4j
- R: Schema registry
	- Estuve hablando con Javi Almodovar y orientando a Rodrigo sobre cómo funcionar (SpecificRecord, etc)
	- Van a necesitar algo parecido al entity metadata: hay que pensar cómo darles esto. Tema de la idempotencia, etc
- R: Seguimiento de calidad
	- Debate en torno al proceso, etc. Recalcamos que los equipos han de consensuar con su arquitecto el diseño de las features
	- Se va a invitar a los arquitectos a los refinamientos
	- Si cualquiera de nosotros ve que no se ha avisado al arquitecto, intentaremos añadirle al proceso
- R: Hablamos del tema e2e
	- Queda pendiente Joaquín de convocar para hacer un inception del proyecto

==========

## 11/03/2024

- #DPA-1733 
	- Documentando la parte de las funcionalidades del starter actual
- R: Checkpoint primera semana con Julio

## 12/03/2024

- Tema de "Maple"
	- Al final no hacemos nada. Preguntan por las dependencias de librerías (jajaja)
- #DPA-1966 
	- El equipo de paycards ha bloqueado la tarea porque al parecer no es simplemente un cambio del endpoint al que se está llamando sino que hay que cambiar la estructura
	- Quedo en hablarlo con Yair para enterarme de cuál es la problemática y trasladarsela a Diego / Mambú
- R: Librerías
	- Les chutamos el dependency tree
	- Tema de usar MIcrosoft Dynamics 365 vs Salesforce
		- Ojo
- R: Event storming baja masiva de clientes
	- Es todo muy absurdo

## 14/03/2024

- #DPA-1997 : Update reprocess-event-batch in all environments up to PRO
	- Nada
- Tema del acceso a espacio de backoffice por parte de los equipos de desarrollo
	- Cantidad absurda de tiempo gastada hablando con gente para el acceso. Todavía a estas horas no solucionado.
	- TODO: Lista de espacios y de personas

==========

## 18/03/2024

- xxx

==========

## 26/03/2024

- Me pongo al día con la solución para la baja masiva de clientes
- Me pongo al día con cómo va el tema de los permisos en Confluence
- Me pongo a investigar sobre #DPA-1966 
	- Creo que el `updateLoanAccount` de la v1 de Mambú es llamado desde muchos otros sitios. Le doy un toque a Yair a ver si lo podemos mirar.
		- Lo miramos y, en efecto, hay un método `com.orangebank.cards.authorization.adapter.cbs.CreateMandatoryRevolvingCardsDebitTransactionsCbsAdapter#breaksIfItIsNotARevolvingCard` que lanza una excepción si no es una tarjeta revolving
		- Quedamos en al menos dejar un comentario, un `@Deprecated` o similar para recordarnos que esta llamada tendría que ser migrada totalmente
- #DPA-1997 
	- Miro la documentación de cómo se utiliza el `reprocess-event-batch`
	- Me pongo a mirar trazas en Kibana para determinar cómo puedo probar esto en DEV

## 27/03/2024

- #DPA-1997 
	- ✅ Reviso la convención de nombres actual para los index patterns de Elastic
	- Voy a localizar el nombre de las DLT de sandbox y voy a buscar la actividad que puedan tener en el entorno de DEV. Si no veo actividad voy a tratar de ver si esas DLT contienen mensajes
		- No veo actividad
		- Me voy a Prometheus y veo que la DLT tiene 745 mensajes
			- Opciones
				- Puedo, directamente, tratar de consumir esos mensajes, buscar los logs de que eso funciona y observar el aumento del offset
					- Voy por este camino 
					- No necesito crear un nuevo consumer group. Voy a hacerlo con el que ya existe (`sandbox.messages_config_created.consumer`)
					- Voy a spring data flow y ejecuto el batch
						- Al parecer el topic no tiene mensajes 🤷
						- 🚫 El mensaje de error (probé con varios offsets) es `com.orangebank.boot.core.exception.NotFoundException: The requested resource could not be found (Cannot find event with offset 1 in topic messages_config_created.sandbox.dlt partition 0)`
				- ¿Debería ver el contenido de esos mensajes?
					- Me pongo a repasar cómo se accede a la CLI de Kafka
					- Me pongo a repasar cómo se hacía el login con el MFA de aws
						- Me doy cuenta de que reinstalé el authenticator y por lo tanto no tengo acceso al clúster. Abro incidencia https://obkesp.atlassian.net/browse/ICCIOL-9174
							- Solucionado! ✅
					- ⚡No consigo utilizar la CLI siguiendo nuestro tutorial
						- 🚫 Bootstrap broker kafka1.internal.dev.proyecto-sol.es:9092 (id: -1 rack: null) disconnected (org.apache.kafka.clients.NetworkClient)
- Alberto Puerto me pregunta por los permisos de Confluence
	- Crear petición, perder el tiempo un rato, etc (-->> https://obkesp.atlassian.net/browse/OBS-46355)
	- 🚫 Bloqueado porque Esther de Prado es la owner del espacio y no está disponible.

==========
## Pendientes

- Tema #DPA-1966 
	- Verificar que marcamos como Deprecado o algo el código que llama a la parte de revolving y explicamos el por qué
- Tema #DPA-1664 
	- Ir implantando lo de los convention tests

- Determinar una lista de temas de buenas prácticas y elegir cómo promoverlo entre los equipos, etc (sin fecha)
- Irse reuniendo con los equipos (1 on 1) (sin fecha)
- Reunirse con Ignacio Merlán y preguntar sobre qué ha pasado al intentar hacer continuous deployment (con Nuria también¿? ->> si)
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY
	- Abrir el melón del WoW

## Seguimiento

- Hacer seguimiento al tema de los permisos en confluence
- Hacer seguimiento de los champion roles (due: 10/11)
- Tema de los endpoints de Mambú y su deprecación
- Darle continuidad a lo del schema registry y a lo del OpenAPI
- Darle continuidad a los tests de convención!
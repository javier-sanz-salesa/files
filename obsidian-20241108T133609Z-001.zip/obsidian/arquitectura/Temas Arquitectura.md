## Organizativos

- Alineamiento de los arquitectos con respecto a la arquitectura
	- https://confluence-orangebank.valiantys.net/pages/viewpage.action?pageId=2004517151
- Funciones del equipo de arquitectura
	- Evitar que arq plantee requerimientos
- Forma de trabajo
	- Comité de arq?
	- Toma de decisiones
- Selección y onboarding de arquitectos
- Revisar el backlog
	- https://confluence-orangebank.valiantys.net/display/DELIVARCH/Architecture+Committees+2022
	- https://obkesp.atlassian.net/jira/software/c/projects/DPA/boards/79
- Equipos agnósticos de dominio

## Funcionales

### Global

- Mapa de referencia de dominios

### Accounts

- Cotitularidad y multititularidad de cuentas
- Alineamiento en la oferta comercial y catálogo de productos
	- https://confluence-orangebank.valiantys.net/pages/viewpage.action?pageId=1931052744
- Motor de precios
- Motor de promociones
- Gestión del overdraft (autorizado vs no autorizado)

### Savings

- Cálculo de intereses en cuentas francesas
- Cálculo de intereses boosted rate
- Proceso de contratación de cuentas
	- Firma digital de documentos (QuickSign)

### Payments

- Cuentas intermedias
- Cheques
- Payment gateway

### Customer processes

- People
	- Gestión de datos maestros (reference data)
- Onboarding
	- Integración con Quicksign
- Documents
	- Integración con Tessi como repositorio de documentos
	- Integración con Tessi para generación de documentos y envío de cartas
		- batch
	- Migración de la generación síncrona de documentos de Jasper Reports a Aspose
		- https://confluence-orangebank.valiantys.net/display/DELIVARCH/12.+EDM+on+1B
- Notificaciones
	- Requisitos de marketing con las plantillas
	- https://confluence-orangebank.valiantys.net/pages/viewpage.action?pageId=1968440400
	- https://confluence-orangebank.valiantys.net/display/DELIVARCH/3.+Alert+handling

### Cards

- Integración con el screening de transacciones (AML?)
- Integración de seguros de tarjetas
- Rendimiento del clearing en OB
	- https://confluence-orangebank.valiantys.net/pages/viewpage.action?pageId=2004452555

### Financial Crime (AML, Fraud, Credit Risk)

- Definición del ámbito de los dominios
- Integración con Experian
- Integración con SAS AML
- Integración con iSoft

### Consumer Loans

- Double run del servicing (SAB vs Mambu)
- Definición del ámbito de los dominios
- Integración con Younited

### Ops (backoffice & customer care)

- Integración con Salesforce (event streaming)
- Opportunities
	- https://confluence-orangebank.valiantys.net/display/DELIVARCH/6.+Opportunities+and+subscriber+concepts

### Accounting / ERP

- Soporte de arquitectura

### Clave de Sol (Dolphin)

- Implementación en 1B

### GB+

- Definición del ámbito de los dominios

### Premium Pack

- Definición del ámbito de los dominios

### Mortgage Loan

- Definición del ámbito de los dominios
- https://confluence-orangebank.valiantys.net/display/DELIVARCH/11.+Mortgage+Loan+Subscription+Integration+on+One+Bank

### Runoff products

### Migración

- Soporte de arquitectura
- Implementación de la PoC
	

## Técnicos

### Security

- Implementación del IDP (sustituyendo a ForgeRock)
- Migrar sca-expiration-batch
- Operational identities en modo multi-tenant (¿?)
- PSD/2
- Domain console -> OKTA
- Login con email o identificador de usuario (¿?)
	- https://confluence-orangebank.valiantys.net/display/OB/ID+for+Login
- Flujos de seguridad para 1B
	- https://confluence-orangebank.valiantys.net/display/DELIVARCH/Onebank+-+Target+authentication+flows

### CI/CD

- ¿Quién decide los requisitos?
- Tema de las PR
	- https://confluence-orangebank.valiantys.net/display/INF/Pull+Request+on+any+software+change
- Actualización de Sonar
- Migración de BitBucket
	- Alineación de nombre de proyecto en BB vs dominio

### Platform

- Disponibilidad de múltiples instancias de Mambu (multi-tenant)
- API Gateway
	- https://confluence-orangebank.valiantys.net/display/DELIVARCH/9.+Kong+usage+and+alternatives
	- https://confluence-orangebank.valiantys.net/pages/viewpage.action?pageId=1990137717
	- Herramienta de publicación
	- Procesos batch (Airflow)
		- https://confluence-orangebank.valiantys.net/display/DELIVARCH/5.+Airflow+-+Kubernetes+PoC
		- https://confluence-orangebank.valiantys.net/display/DELIVARCH/5.+Scheduling+Tool
		- https://confluence-orangebank.valiantys.net/display/DELIVARCH/Batch+PEP+-+Technical+Architecture+Document
- Istio
- Requisitos con los entornos (desde desarrollo)
- Observabilidad y monitorización
	- Segregación de trazas por tenant
		- https://confluence-orangebank.valiantys.net/display/DELIVARCH/2.+Multi+Countries+Architecture
- Kafka
	- Políticas de retención
		- Revisión eventos
	- Tópicos compactados
	- Publicación de los asyncapi.yml para data lake
		- Revisión de los eventos
	- Avro & Schema Registry
	- Julie (Plantillas y split)
	- (DataLake) Consumo de las cabeceras
	- Data Lineage
- Uso de LeanIX
	- https://confluence-orangebank.valiantys.net/display/AE/IT+Standards

### Librería de arquitectura

- Revisar el backlog
- Sacar la release
	- cabecera metadatos de migración
- ElastiCache support multi-tenant
- Upgrade a soporte de Elastic (6 -> 7)
- Java 17
- Spring boot 3
- Upgrade de asyncapi y openapi generator
- Generación de los catálogos de api y eventos (artifactory)
- Quitar Waratek
- Generación de diagramas como código
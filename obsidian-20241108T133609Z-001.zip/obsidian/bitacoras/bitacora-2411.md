## 04/11/2024

- Intento descargarme reuniones grabadas (UX, FPV, ...) pero no puedo
- No puedo tampoco ponerme a completar documentación (aún no está lista la instancia de Confluence)
- Me tiro el día leyendo sobre BDD, TDD y ATDD
	- Llego a la conclusión de que BDD es una forma de implementar tests basada en comportamiento, generalmente con unas herramientas y un lenguaje (Cucumber, Gherkin, ...)
	- ATDD es una forma de trabajar, que incluye tener una discusión sobre los requisitos (Discuss, Distill, Develop, Demo)
	- Lo que hacemos nosotros es trabajar en ATDD y luego adaptar esos mismos tests a BDD
	- Lo que hemos de añadir es la parte del automator, que es testing e2e

⚡: Requerimientos para que sea un kafka
	- Pendiente de que los demás lo lean
⚡: Acortar la prueba técnica
⚡: Mirar cosas sobre ATDD
⚡: Tema de generar con OpenAPI: completar las cosillas que faltan en documentación y en la implementación

==========

## Tareas Pendientes

- Tema de ifs.dev
- Crear un runbook y revisar la parte del `endpoints-apigateway-publisher` y del `database-changelog-executor`
- **Documentación del desarrollador**:
    - Continuar con la documentación del desarrollador para nuevos desarrollos.
    - ⚡**Revisar la documentación** que Jorge va a preparar sobre la generación de controladores a partir de las especificaciones de OpenAPI y darle una revisión final.
- Soporte a Kafka + Avro
	- **Mover los módulos del starter de Kafka + Avro** a `ebro-boot`.

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
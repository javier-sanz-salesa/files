```xml
<properties>
	<docker.showLogs>true</docker.showLogs>
</properties>
```

| Responsable                       | Squad o chapter         | Arquitecto de Soporte |
| --------------------------------- | ----------------------- | --------------------- |
| Javier Sanz                       | Backend                 | N/A                   |
| Jose Manuel Sánchez               | Arquitectura            | N/A                   |
| Álvaro Morgan                     | Seguridad               | N/A                   |
| Julio Vegara / Alejandro Espinosa | Front Android / iOS     | N/A                   |
| Ivan Arranz                       | Front Web               | N/A                   |
| Ivan Morales                      | QA                      | N/A                   |
| Alberto Puerto                    | Salesforce              | N/A                   |
| Yair Segura                       | PayCards                | David González        |
| David Bijleveld                   | Banking                 | Javier Sánchez        |
| Jorge Pacheco                     | Banking (cuentas)       | Javier Sánchez        |
| Javier Casado                     | Credit                  | Jose Manuel Sánchez   |
| Arturo Quintana                   | CC-OPS-FinCrime (ACDC). | Santiago Toledano     |


## 03/07/2024

- Evento con los de IberCaja

## 04/07/2024

- Descubro que el proceso batch siempre se había estado lanzando 2 veces por cada prueba en el `reprocess-event-batch` pero por lo que sea había funcionado
- Reuniones
	- Daily
	- Event storming financiación punto de venta
	- Santi sobre la tarea del CustomReflectData
	- Joaquín y Nico sobre el tema de las licencias
- Errores varios con los tests
	- Descubro fallo con que el KafkaConsumer no debería cerrarse entre invocaciones
		- ⚡ Quito el close pero dejo pendiente ver si podemos cerrarlo de alguna forma
			- ✅ Veo que esto no es necesario porque el consumer se cierra solo cuando termina el batch
	- Fallo con el tipado del kafka consumer de las pruebas
		- Le doy un tipado customizando su listener container
		- Aun así fallan los asserts (puede ser que tengo que limpiar los topics¿?) ->> SI

## 05/07/2024

- R: Weekly
	- Organizamos el tablón
		- 🚫 No puedo crear swimlanes, etc porque no tengo permisos
		- ⚡ Queda terminar de barrer el tablón la semana que viene (¿siguiente weekly?)

==========

## 08/07/2024

- R: Chapters
- R: Daily/Weekly
- R: w/Nico - Hablamos del CLI, etc
- #EBROA-29
	- Falla el consumo de un rango de offsets
		- Mi hipótesis es que no puedo utilizar el mismo consumer
	- Arreglo todo y arreglo los tests, que tenían problemas de orden
	- Paro la publicación de esta versión ya que es incompatible con el consumo de las DLQ con EventJournal
	- Saco una rama
		- Subo a la última versión de la arquitectura con spring boot 2.7.x
		- Pongo el nuevo tile de kafka y falla
		- Subo a la última versión de la arquitectura con spring boot 3.3
		- Parece que la parte de kafka la consigo migrar
		- ⚡Me quedo en migrar la parte de spring batch, que no sé lo que estoy haciendo (tengo conflictos con la nueva forma de configurar spring batch)
			- Mirar aquí: https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/blog/2024/06/28/4270489735/OB+Boot+x.y.z+will+be+released

## 09/07/2024

- #EBROA-29 
	- Migrar el reprocess-event-batch a la última versión de la arquitectura con spring batch 3.3
		- Migro la configuración a spring boot 3
		- Me encuentro el problema con el PlatformTransactionManager. Pongo el que había antes tirando de `@Qualifier`
		- Empiezan a fallar los tests porque no encuentran los mensajes
			- Paso de usar `subscribe` a `assign`. Lo dejo así porque es un método más sencillo al que directamente le pasas una partición, pero no tiene efecto
			- El problema es que los mensajes tardan un poco más en ser publicados de forma efectiva. Meto un par de Thread.sleep
			- ⚡ Tengo que rematar esto
				- Limpiar cosas que he metido
				- Subirlo a git y cerrar la tarea

## 10/07/2024

- Me pongo a leer los artículos que envió Jose sobre BIAN para aplicarlos al desarrollo de #FPV
- R: [FPDV] bounded context
- R: Temas del `reprocess-event-batch`
	- Hay varios temas
		- Subir lo que hay a la última versión de arquitectura con spring boot 3?
		- Hacer que consuma y produzca eventos binarios
		- Subir la versión del tile de Kafka
		- Ir probando las sucesivas versiones en desarrollo
		- Problemas "raros"
			- `PlatformTransactionManager` duplicado
			- Asincronía cuando enviamos eventos en Kafka 3.7.0
	- Javi publica la última con spring boot 2 y sube a spring boot 3
	- Carlos se queda con el tema de los cambios específicos para Avro
- Genero el reporte de licencias con todo

## 11/07/2024

- R: Tema de la incompatibilidad entre las versiones de la base de datos de Spring Batch
- R: Tema del "CLI MAPLE"
	- Propuesta: Use case services
		- Servicios que orquesten un caso de uso que puede ser más o menos cross (contratar un préstamo, hacer un onboarding, ...)
		- Son servicios separados del resto de servicios. Se despliegan en su propio namespace
		- Utilizan las librerías de arquitectura y todas sus facilidades
		- Estos servicios deberán ser capaces de ejecutar suites de pruebas (ATDD) escritas en Gherkin por un PO (ya veremos cómo)
		- Estos servicios podrán ser el backend de una eventual CLI
		- Estos servicios serán desarrollados por el equipo de desarrollo. Aunque eventualmente podría ser el squad de QA
	- ¿Quién?
		- Equipo multidisciplinar
			- 1 arquitecto de soporte
			- 2 desarrolladores backend. A ser posible con algo de experiencia
			- Gente de QA. En principio Ramiro.
	- TODO's
		- Escoger las personas
			- Santi como arquitecto (puedo ponerme yo cuando vuelva de vacaciones)
			- Desarrolladores. ¿Quiénes?
				- ⚡Hablar de esto con Joaquín / Nico
- Tema de las dependencias
	- Reviso a mano las dependencias de las que nos han dicho que hay que revisar
		- En principio no hay problemas (hay licencias mixtas pero la principal es permisiva, etc)
		- Las que no son permisivas (strong copyleft) aplican a la distribución de software
		- Parece que la herramienta no es demasiado exacta, por lo que vemos
		- Propuesta: Que entre todas las licencias encontradas se revisen las "problemáticas"
	- Reviso las dependencias que no tienen info de versiones

## 12/07/2024

- ⚡Hablar sobre el tema de equipos (squads, QA, ...)

==========
## Pendientes

- Ver los equipos que vamos a montar
	- ¿Nos fijamos en Bian?
	- ¿Qué pasa con la gente esa que supuestamente va a entrar de Hiberus?
	- Hay que seguir mirando BIAN + el event storming de Financiacion punto de venta
		- De este modo iremos viendo los equipos que necesitamos
- ⚡Terminar de barrer el tablón actual de DPA para moverlo al de EBROA
	- 🚫 Necesito permisos de administración de ese tablón
- Tema #DPA-1664 
	- ⚡ Ir implantando lo de los convention tests

## Seguimiento

- ⚡ Tema de los permisos en confluence
	- 📆 El **4 de Abril** vuelve Julián de vacaciones. Seguimos empujando con esto
	- El 9 de Abril vuelvo a preguntar en el chat
- ⚡ Mejoras en el way of working
	- Hablar con Ivan

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
	- En caso de que el proyecto tenga continuidad asegurada
- 💡♨️ Dar pasos hacia el continuous deployment
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY
## 01/10/2024

- (R) Daily
- (R) Financiación Punto de venta - CLI - Day 0
	- Javi Casado nos hace una demo y el equipo se va a poner a generar tests e2e para el automator sobre `product-brokers`
- (R) WoW & Estrategia calidad
	- Sacamos una serie de temas de organización y habrá que seguir con más (está tomando notas Ivan Morales)
- ✅ El equipo de backend ya tiene en sus manos los documentos del "inside a microservice" e "inside a batch process"
- ✅ Actualizo el catálogo de links con algunas cosas que faltaban
- ✅ Revisado el documento "Our own BIAN landscape"
	- Intento sacar una equivalencia a los equipos actuales
	- Entendiendo la propuesta. Me la leo un par de veces
	- No tengo nada en concreto. Veremos mañana cuando hablemos de ello

## 02/10/2024

- (R) Daily
- (R) Daily CLI
- (R) Our own BIAN landscape
- (R) WoW & Estrategia Calidad
	- Contratar un agile coach
	- Reducir el número de syncs (pero no la IT Sync 😱)
	- Enfoque en trabajo profundo durante periodos prolongados

- Respondiendo las dudas del chat de backend
	- Tema aparte lo de los mappers!
	- Le ofrezco soporte con el tema a Javi
- Tareas en el Jira
	- Repaso lo que falta. Desestimo lo que es documentación y divulgación, que va implícito
	- Creo la tarea para mover los módulos de `ebro-boot` y me la asigno
	- Jorge ya tiene creada la tarea con lo del código (EBROA-126)

## 03/10/2024

- (R) Daily
- (R) Presencial Ibercaja (tarde)

- #EBROA-136: Soporte equipo de backend (tema mappers, etc)
- #EBROA-139: 
	- Instalo Java 21
		- ⚡ Falta documentar!!
	- No consigo hacer el build de `ebro-boot` por problemas con Docker

## 04/10/2024

- (R) Daily
- (R) Weekly
- (R) c/ Juanra Ríos, Álvaro Morgan: sobre endpoint de apoyo al e2e en product-brokers
	- Álvaro lo va a mirar para hacer su propia recomendación
- (R) Kafka Sync
- (R) Our own BIAN landscape proposal: infrastructure impact analysis.

- Revisando la documentación del endpoints-apigateway-publisher: Ok. Es un poco confuso pero es mejor que nada
		- ⚡: TODO: Crear un runbook con esto
- #EBROA-143: 
	- Echando un vistazo a las helm charts y cómo funcionan los hooks, etc
	- Echando un vistazo a la blueprint sobre Jikkou, etc
		- ❓Los topics "private" representan que un mismo servicio produce y consume en el mismo topic?

==========

## 07/10/2024

- (R) Daily
- (R) Daily CLI
- (R) c/Álvaro
	- ⚡ Endpoint de test en `product-brokers`: Vamos con ello pero se va a encargar de definir una estrategia para hacer esto correctamente
- (R) Our own BIAN landscape proposal: business impact
- (R) Primeros pasos - Loans / Seguridad

- #EBROA-136 
	- Migro los artículos de Lombok y MapStruct para incluir las observaciones hechas por el equipo de desarrollo
	- Incluyo las propuestas del equipo de desarrollo (configuración y alguna más)
	- Terminado

## 08/10/2024

- (R) Daily
- (R) C/ A.Quintana: Hablando sobre el inside a microsevice

- Aprobado el blueprint del `database-changelog-executor`
- #EBROA-143 
	- Repasando la documentación existente y creando el esqueleto de la guía del desarrollador
	- Comprobando las dudas con el código existente.
	- Convocada reunión de dudas, etc mañana
- Temas de lo del convenio
- ⚡: A la espera de que Nico me diga algo sobre si vamos a enseñar el automator o qué.

## 09/10/2024

- (R) Daily
- (R) Jikkou: Uso del desarrollador
	- Reunión para la semana que viene convocada
- (R) Daily CLI team
	- No la hacemos, creo que por un malentendido de Ivan
	- Mañana he convocado un punto de situación, que va a ser un informe para que Nico decida qué hacer a efectos de demo, etc.

- #EBROA-143 
	- Adapto el nombrado de topics a lo que hay (blueprint de Jikkou y guía de diseño de la topología)
	- Decisiones: full o short name en dominio. ifs en vez de isf
	- Creada la guía del desarrollador. Falta la parte de abajo aunque ya la tengo clara

## 10/10/2024

- (R) Daily
- (R) Automator: punto de situación: Daily todos los días hasta cerrar
- (R) Ensayo de la demo IB
- (R) Reparto preliminar de equipos

- #EBROA-143 
	- Documento el borrado de topics
	- Tratando de entender la parte del transaction id y los consumer groups
		- ¡¡Lo entiendo!!
			- Al final resulta que tenemos todos los permisos adecuados para todos los transactionIds y consumer groups que **comiencen por** `<nombre_de_topic>.<agente>` (siendo el agente el nombre del servicio que produce o consume)

## 11/10/2024

- (R) Daily
- (R) Weekly
- (R) "security" in the BIAN landscape
- (R) c/ Joaquín (temas varios)

- #EBROA-143: Redactando la parte de los transactionId y consumerGroup
	- ✅ Termino (in review)

==========

## 14/10/2024

## 15/10/2024

- (R) Daily
- (R) Daily CLI
- (R) Kafka and Jikkou: Next steps

- #EBROA-144:
	- Repasando lo que hay y viendo qué bloqueos tenemos con esto
	- Recopilo la info en la historia de usuario

## 16/10/2024

- (R) Daily
- (R) Istio Ingress - Egress
- (R) BAMBU - status - Internos
- (R) Post demo: The Plan Going Forward

- Consigo hacer que funcione el cliente de Docker de las pruebas de integración del `ebro-boot`
	- Hay que dejar las credenciales en el `config.json` sin hacer `docker login`. Cuando se las traga el `credStore` ya no funcionan

## 17/10/2024

✅: Hacer copia de seguridad de lo que hay en el sharepoint
✅: Convocar a los TLs y a Nico para ver la distribución preliminar de los equipos
✅: Avisar a los equipos con el tema de las ramas

## 18/10/2024

- (R) c/ Arturo. Modificaciones propuestas al reparto de equipos
- (R) Daily
- (R) Weekly arquitectura
	- Hablamos de nuestras prioridades y dejamos fuera el tema de multi-tenant
- (R) Tema de dominios y customer-care / backoffice
- (R) Automator

- Montando la reunión de comunicar lo de los equipos

==========

## 21/10/2024

- (R) Daily
- (R) c/ Nico para hablar del tema del QA Automation
- (R) Composición preliminar de los equipos

- Preparando la slide y la reunión de equipos
- #EBROA-144 
	- Siguiendo la guía
	- Adaptar algo es bastante complejo. Lo dejo a medias
	- Creando un API desde 0
		- Empiezo a crear la guía en sucio
		- Tema de `x-field-extra-annotation`
		- Tema de tags de validación
		- Formateo: Utilizo spotless y da buenos resultados
		- Subir versiones de jackson mínimo a 2.17.1 y la del propio generador (hago overwrite en local)

## 22/10/2024

- Jornada presencial Ibercaja, etc

## 23/10/2024

- (R) Procedimiento Gestion de secretos en Ebro

- Parando el tema de que cerraran las cuentas de AWS hasta que no nos quede otra
- Discutiendo el tema de las entrevistas y no se qué
- Recuperando mi acceso a vive orange, descargando docu y realizando las gestiones necesarias por RRHH
- Convocar la reunión de novedades en el framework
- Recopilando lo que vamos a contar y ver lo que falta
	- ⚡Repasar cosas
	- Creación o migración de un microservicio: A ver si llegamos con el autoservicio
	- ⚡Sigo a ver si da tiempo a lo de generación de las APIs (al menos lado servidor, espero que lado cliente)

## 24/10/2024

- (R) Job description & code challenge
- (R) C/ Arturo para hablar de temas del inside a microservice

- Generado el Job Description para backend developer y tech lead
- Accediendo a la cuenta de AWS
	- 🚫 Me encuentro con un problema que están solucionando
- #EBROA-144: Primera versión de la guía de generación de código con el API up
	- Me faltan un par de detalles
	- Creo una historia con mejoras que hay que hacer

## 25/10/2024

- (R) Daily
- (R) A Glimpse into the FPV
- (R) SSO con Ibercaja

- #EBROA-144: Preparando la presentación

==========

## 28/10/2024

- (R) Daily
- (R) Chapters - Revisión JobDescription & CodeChallenge
- (R) Definicion nombre topics de IAM

- Chapters, code challenge
	- Movido documento con atribuciones del chapter lead (los permisos)
	- Test con ChatGPT y nuestra prueba de código
- #EBROA-144: Avanzo en la presentación de novedades en EBRO

## 29/10/2024

- (R) Agentes autónomos (crewAI)
- (R) UX - Research con agentes
- (R) Gestor de Eventos: Kafka

- #EBROA-144: Terminado.
	- ⚡: Falta poner la parte de seguridad y la de BIAN. Yo crearía tarea con la siguiente charla
- Generando documento con los requisitos para Kafkaç
	- ⚡: Pendiente de que los demás lo lean
- Terminando documento de los chapters y atribuciones

⚡: Descargarse la reunión de UX para pasarselo a Javi
⚡: Requerimientos para que sea un kafka
	- Pendiente de que los demás lo lean
⚡: Acortar la prueba técnica
⚡: Mirar cosas sobre ATDD
⚡: Tema de generar con OpenAPI: completar las cosillas que faltan en documentación y en la implementación

==========

## Tareas Pendientes

- Tema de ifs.dev
- Crear un runbook y revisar la parte del `endpoints-apigateway-publisher` y del `database-changelog-executor`
- **Documentación del desarrollador**:
    - Continuar con la documentación del desarrollador para nuevos desarrollos.
    - ⚡**Revisar la documentación** que Jorge va a preparar sobre la generación de controladores a partir de las especificaciones de OpenAPI y darle una revisión final.
- Soporte a Kafka + Avro
	- **Mover los módulos del starter de Kafka + Avro** a `ebro-boot`.

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
## Cucumber

`mvn clean install -Dcucumber.filter.tags="@this" -o`
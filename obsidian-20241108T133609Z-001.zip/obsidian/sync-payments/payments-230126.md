- El equipo pide poder utilizar PRs
	- Se pueden utilizar, lo que no hay es construcción de ramas de feature o PRs obligatorias. Es un tema del equipo


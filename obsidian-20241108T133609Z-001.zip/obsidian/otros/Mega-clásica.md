Javi
- 2 packs de 24 cervezas de Mahou roja
- 2 Tanquerays y 2 Brugales

Antonio
- ¿?

Charlie
- Pan (8 barras y 2 hogazas o similar)
- Salsas (Ketchup, BBQ)

Díaz
- Bebidas no alcohólicas
	- 4 litros tónica
	- 8 litros cocacola
	- 4 litros fanta naranja
	- 2 litros fanta limon
	- 1 nestea
	- 1 aquarius
	- 1 Pulco

Pull
- Carbón (3 sacos)

Patrick
- 12Kg de carne (3 de cordero, el resto de lo que sea, comprar hamburguesas)

Ramón
- Picoteo
	- Patatas, snacks, ganchitos, fuet, jamon york, encurtidos, queso, s3 torreznos, gominolas
- Desayuno
	- 6 litros de leche semidesnatada
	- Desayuno surtido
	- Cosas para untar en tostadas (paté, tomate, ...)

Otros (los compraremos allí en principio)
- Ensaladas (bolsa, tomates, cebolla)
- Pizzas
- Fruta (Manzanas y plátanos sobre todo)
- Yogures

## 02/09/2024

- **Reuniones:** (30%)
    - Daily
    - Daily CLI
    - Weekly entre infra y arquitectura.
    - C/ Joaquín:
	    - TLs y Arquitectos
	    - Arq seguridad
- **Soporte a compañeros:** (40%)
    - Ayuda a Juanma Tosar con un problema de seguridad (RBAC).
	    - ⚡: Pendiente hablar con Carlos Guzmán para que me explique el proceso y dónde hay que mergear las cosas
	- Ayuda a Juanma con el tema del doble token
    - Asistencia a Alberto Segovia con la organización de paquetes en `automator`.
    - Apoyo a Ramiro con un problema en el endpoint de generación de contratos.
- **Tareas #EBROA-99:** (25%)
    - Edición del Links Catalog y finalización de la tarea.
- **Gestión de permisos:** (5%)
    - Respuesta a la solicitud de permisos de administración en el tablón del equipo CLI.

## 03/09/2024

- **Reuniones:** (2.5h)
    - Daily
    - Reunión interna: initializr y otros temas
- **Soporte y Comunicaciones:** (0.5h)
    - Contacto a Carlos Guzmán para coordinar explicación sobre los merges en `security-cluster-rbac`
    - Soporte a compañeros de la CLI en temas de arquitectura (paquetizado, uso de entities, mappers, ...)
- **Gestiones**: (0 chunks)
	- Cambio de contraseña del dominio
- **Tareas #CLI-5:** (2.5h)
    - Desarrollo y pruebas en el `PersonCreator` con la lógica de reintentos.
    - Despliegue de cambios en DEV y verificación de trazas en Kibana.
    - Solución de errores de alineamiento entre la entidad de base de datos y la tabla.
    - Verificación de logs post-despliegue y análisis de comportamiento del sistema con respecto a los eventos de `person created/updated`.
    - Reflexión sobre el scope de la tarea actual, con posibilidad de incluir `Delete prospect`.

## 04/09/2024

- **Reuniones:** (1 hora)
	- **Daily**
	- **Daily CLI**
- **Tareas #EBROA-99:** (30 minutos)
	- Moví la documentación al workspace de Bambú. Tarea finalizada.
- **Tareas #CLI-5:** (5 horas)
	- Implementación y despliegue del listener de los eventos que indican la baja de clientes y prospects
	- Reactivando el envío de mails: `automator`, `people`, `onboarding`.
	- Solución problemas:
		- Consumo erróneo de evento person updated. Campo "countryCode"
		- Consumo erróneo del enlace del mail de verificación. Implemento la extracción del token del correo.
- **Soporte a Compañeros:** (30 minutos)
	- **Juanra**: Validación del endpoint de create customer
	- Alberto Segovia sobre el `personId` para el onboarding del cliente.

## 05/09/2024

-  **Reuniones:** (1.5 horas)
	- **Daily** (9:30-11:00)
- **Tareas #EBROA-99:** (1.5 horas)
	- **Certificados y documentación:**
	    - Actualización de la información de instalación de nuevos certificados para la construcción con Maven.
	    - Modificación de dominios añadiendo el sufijo "-devtools".
	    - Construcción de `ebro-boot` en local
- **Tareas #CLI-5:** (3.5 horas)
	- Verificación del despliegue del flujo completo con la verificación del email.
	- Actualización de la colección de Postman para el create user.
	- Añadiendo casos en tests de integración existentes, atascado con el uso de Mountebank y su client `mbtest`.
	- Sustitución de Velocity por ImposterBuilder.
- **Otros:** (30 minutos)
	- **RRHH:** Grabación de vídeo para el evento de despedida.
	- Generar lista de software a instalar en los futuros equipos de Ibercaja

## 06/09/2024

- **Reuniones:** (2 horas)
    - **Daily** (9:30-10:30)
    - Daily CLI (10:30-11:00)
    - **Alcance del automator** (14:00-14:30)
        - Definimos que el caso de uso del MVP es el onboarding de un préstamo.
        - Migración del código de `automator-cli` a `automator-launcher`.
        - Reorientación de esfuerzos para soporte de ese caso de uso desde `automator-backend`.
        - Se sacarán tareas el lunes en la reunión que tenemos L, X y V para añadirlas al tablón del proyecto CLI.
- **Tareas de planificación:** (1.5 horas)
    - **Alcance del proyecto CLI:**
        - Reflexión sobre el alcance del proyecto de la CLI.
        - Convocatoria de una reunión para discutirlo.
    - **Informe sobre onboarding:**
        - Creación de un informe con información del onboarding de cuentas para el equipo del CLI
        - Lo añado al informe como un archivo .md
- **Soporte a Compañeros:** (45 minutos)
    - **Juanra:** Soporte con un problema encontrado en el automator.

==========

### Informe semanal: 02/09/2024 - 06/09/2024

#### **Reuniones** (8 horas en total)

- **Daily y Daily CLI**: Participación diaria en reuniones para coordinar tareas y avances.
- **Reunión interna y Weekly**: Coordinación con infra y arquitectura.
- **Alcance del automator**: Definición del MVP enfocado en el onboarding de préstamos, migración del código de `automator-cli` a `automator-launcher` y reorientación del soporte desde `automator-backend`. Planificación de tareas para continuar el proyecto.
- **Temas organizativos del chapter**: Rol de arquitectos y TLs, apoyo en arquitectura de seguridad

#### **Tareas #CLI-5** (16 horas en total)

- **Desarrollo y despliegue**: Implementación y despliegue del listener para los eventos de baja de clientes/prospects y verificación del flujo completo con la verificación del email.
- **Solución de problemas**: Resolución de errores relacionados con el consumo de eventos (`person updated`, `countryCode`) y extracción del token del mail.
- **Pruebas y ajustes**: Tests de integración, ajuste de Mountebank con el client `mbtest`, y sustitución de Velocity por ImposterBuilder.
#### **Tareas #EBROA-99** (4.5 horas en total)

- **Documentación y Certificados**: Actualización de la información sobre configuración del entorno para la nueva plataforma Ebro (maven, docker, ...): Certificados para la construcción con Maven. Movida la documentación al workspace de Bambú. Construcción de `ebro-boot` en local.

#### **Soporte a Compañeros** (2.5 horas en total)

- Labores de soporte a compañeros dentro del proyecto de CLI
#### **Otros** (1 hora)

- **RRHH**: Grabación de vídeo para el evento de despedida.
- **Planificación**: Generación de lista de software a instalar en los futuros equipos de Ibercaja.
### Resumen de Logros:

- **Automator y CLI**: Se avanzó en la planificación del proyecto CLI, con definición clara del caso de uso (onboarding de préstamos) y reorientación del soporte. Se finalizó la prueba de concepto con un circuito básico de creación de usuario con verificación de mail
- **Documentación**: Se actualizó y organizó la documentación del desarrollador con respecto a la nueva plataforma Ebro.
- **Soporte técnico**: Soporte efectivo a varios compañeros del proyecto CLI

==========

## 09/09/2024

- **Reuniones:** (2 horas)
    - **Daily y Daily CLI**: Refinamiento de tareas para la demo de CLI.
    - **Bambú MVP Setup**: Participación en la reunión para configuración del MVP en Bambú.
- **Tareas #CLI-5:** (30 minutos)
    - **Planificación y pruebas**: Continuación de la planificación del proyecto CLI, enfocada en el onboarding de préstamos. Avance en el traspaso de tests de `automator-cli` a `automator-launcher` y trabajo en los endpoints de soporte a loans.
- **Tareas #EBROA-103:** (1.5 horas)
    - **Documentación EBRO**: Creación de documentación "inside a microservice".

## 10/09/2024

- **Reuniones:** (30 minutos)
    - **Daily**: Revisión y coordinación de tareas.
- **Tareas #EBROA-103:** (6 horas)
    - **Documentación de "Inside a Microservice"**: Continuación del trabajo en la documentación relacionada con EBRO dentro de un microservicio. La página de documentación está en Confluence y se sigue editando.

## 11/09/2024

- **Reuniones:** (4 horas)
    - **Daily y Daily CLI**: Revisión diaria de tareas y avances.
    - **Briefing técnico plataforma**: Discusión técnica sobre la plataforma.
    - **Feedback y temas de organización**: Participación en discusiones sobre la organización del equipo.
- **Tareas AWS:** (1 hora)
    - **Comprobación de acceso a AWS**: Instalación de la CLI v2 de AWS y verificación de acceso. No se instaló Kubernetes 1.30 debido a riesgos con el acceso al cluster de desarrollo.
- **Tareas #EBROA-103:** (2 horas)
    - **Documentación de "Inside a Microservice"**: Finalización de la documentación de EBRO en un microservicio, quedando a la espera de revisión.

## 12/09/2024

- **Reuniones:** (30 minutos)
    - **Daily**: Se comenta la salida de Carlos en 15 días. Es necesario hablar con Joaquín sobre equipos y organización.
- **Tareas del chapter:** (2.5 horas)
    - **Nueva prueba de código para backend Ibercaja**: Recuperación y actualización de la prueba de código anterior, ajustes en formato y contenido, y subida a Confluence en el espacio de "development". Se pasó a Nico para feedback.
- **Tareas pendientes:** (Feedback esperado)
    - **Inside a microservice**: A la espera de feedback sobre la documentación.

## 13/09/2024

- **Reuniones:** (2 horas)
    - **Daily**: Incorporación de Jorge Pacheco al equipo de arquitectura.
    - **Weekly de Arquitectura**: Revisión de tareas, incluyendo la migración de la guía del desarrollador y explicación sobre el montaje de Dataflow con minikube.
    - **Reunión CLI**: Discusión sobre el alcance de la prueba de concepto de la CLI.
- **Tareas de planificación y organización:** (1.5 horas)
    - Reflexión sobre problemas de organización.
    - Definición de tareas para la próxima semana: revisión del servidor de DataFlow, confección de la guía de desarrollo y temas organizativos.
    - Creación de reunión para el lunes sobre "inside a microservice".
    - Solicitud de permisos para Jorge en el tablón de Arquitectura.
- **Documentación y APIs:** (30 minutos)
    - Búsqueda y revisión de la generación de APIs a partir de OpenAPI, localización de la documentación existente en Confluence.

==========

### Informe semanal: 09/09/2024 - 13/09/2024

#### **Reuniones** (9 horas en total)
- **Daily y Daily CLI**: Reuniones diarias para revisar tareas, avances y planificación de la demo de CLI.
- **Bambú MVP Setup**: Configuración del MVP para el proyecto en la reunión de Bambú.
- **Briefing técnico plataforma**: Exposición sobre la plataforma y sus componentes a la gente de Ibercaja.
- **Feedback y temas de organización**: Participación en discusiones sobre la organización del equipo.
- **Weekly de Arquitectura**: Dataflow en local con minikube.
- **Reunión CLI**: Definición del alcance de la prueba de concepto de la CLI.

#### **Tareas #CLI-5** (2 horas en total)
- **Planificación y pruebas**: Continuación de la planificación del proyecto CLI.
- **Prueba de concepto y refinamiento**:

#### **Tareas #EBROA-103** (9.5 horas en total)
- **Documentación de "Inside a Microservice"**: Creación y finalización de la documentación sobre el funcionamiento de EBRO dentro de un microservicio. La documentación está a la espera de revisión en Confluence.

#### **Tareas del chapter** (2.5 horas en total)
- **Prueba de código para incorporaciones backend en Ibercaja**: Recuperación, actualización y subida de la prueba de código anterior en Confluence para futuras incorporaciones. Se pasó para feedback.

#### **Tareas del entorno de desarrollo** (1 hora en total)
- **Comprobación de acceso a AWS**: Instalación de la CLI v2 de AWS y verificación de acceso, con precaución sobre la versión de Kubernetes debido a problemas con el acceso al cluster de desarrollo.

#### **Tareas de planificación y organización** (2 horas en total)
- Reflexión sobre problemas de organización y definición de tareas para la próxima semana
- Solicitud de permisos para Jorge en el tablón de Arquitectura.

### Resumen de Logros:
- **Documentación técnica**: Finalización de la documentación "Inside a Microservice" para EBRO, a la espera de revisión.
- **CLI y Automator**: Refinamiento de tareas y planificación para la prueba de concepto del CLI.
- **Prueba de código**: Actualización de la prueba de código para futuras incorporaciones en Ibercaja y subida a Confluence.
- **Planificación organizativa**: Definición de tareas propias para la próxima semana y reflexión sobre temas organizativos de cara a la próxima semana

==========

## 16/09/2024

- **Reuniones:** (3 horas)
    - **Daily y Daily CLI**: Coordinación de tareas y avances.
    - **Reuniones sobre "Inside a Microservice"**: Decisión de utilizar DDD para la estructura interna de los microservicios. Revisión de ejemplos y diseños del equipo.
    - **Bambú MVP Setup**: Continuación en la configuración del MVP de Bambú.
- **Tareas #EBROA-103:** (4 horas)
    - **Revisión de ejemplos DDD**: Exploración del ejemplo `accounts/vertical_slicing` y lectura de la documentación generada por el equipo de `product-brokers`.
    - **Adaptación de la documentación**: Modificación de la documentación de "inside a microservice" para alinearla con la estructura DDD.

## 17/09/2024

- **Reuniones:** (1 hora)
    - **Daily**: Coordinación de tareas.
    - **Llamada de Jose**: Revisión de la configuración del nuevo clúster.
    - **Llamada de Nico**: Discusión sobre calidad, organización y perfiles técnicos.
- **Tareas #EBROA-103:** (5 horas)
    - **Adaptación a DDD**: Finalización de la adaptación de la documentación de "inside a microservice" a la estructura DDD. Lista para revisión.

## 18/09/2024

- **Reuniones:** (3 horas)
    - **Daily**
    - **Daily CLI**: Generación de nueva historia de usuario para la generación de informes (`CLI-34`) con observaciones de Nico.
    - **Revisión de propuesta batch**: Discusión sobre la organización interna de los servicios de batch, con preferencia por organización por funcionalidad.
- **Tareas técnicas:** (4 horas)
    - **Actualización de `kubectl`**: Trabajo en la actualización de `kubectl` y confección de la guía de desarrollo.
    - **Revisión de la guía de `dbeaver`**: Lectura y revisión de la guía preparada por Jorge sobre `dbeaver`.
- **Soporte:** (30 minutos)
    - Soporte al equipo de desarrollo con la configuración de la VPN y accesos a Confluence.

## 19/09/2024

- **Reuniones:** (1.5 horas)
    - **Daily**: Coordinación de tareas y avances.
    - Discusión sobre temas de organización dentro del equipo.
- **Tareas técnicas:** (1.25 horas)
    - **Documentación del desarrollador**: Trabajo en la sección de Networking
    - Decisión de quitar el prefijo "[RunBook]" de los runbooks y usar una etiqueta en su lugar.
- **Soporte y problemas**: (1 hora)
    - **Acceso VPN**: Resolución de problemas relacionados con la conexión a la VPN.
    - **Actualización del sistema operativo**: Mantenimiento y actualización del equipo.

## 20/09/2024

- **Reuniones:** (2 horas)
    - **Daily**
    - **Daily CLI Team**: 
	    - Se nos ocurre un requisito: Estadísticas de las ejecuciones de e2e tests utilizando informes de cucumber y la posibilidad de persistirlos en una base de datos. El equipo va a ver alternativas.
	    - También se discutió la migración de artefactos a nuevas versiones de la arquitectura EBRO (desestimado de momento)
	    - Revisión de documentación tanto funcional como técnica de los nuevos desarrollos en la plataforma EBRO.
- **Tareas técnicas:** (1.5 horas)
    - **Guía del Kafka CLI**: Trabajo continuado en la guía del Kafka CLI, parte de la documentación del desarrollador.

==========

### Informe semanal: 16/09/2024 - 20/09/2024

#### **Reuniones** (10.5 horas en total)
- **Daily y Daily CLI**: Coordinación diaria de tareas y avances.
- **Inside a Microservice**: Decisión de utilizar DDD para la estructura interna de los microservicios y revisión de ejemplos y diseños compartidos por el equipo.
- **Bambú MVP Setup**: Coordinación para el setup de la plataforma
- **Revisión de propuesta batch**: Discusión sobre la organización de los servicios batch, favoreciendo la organización por funcionalidad, al igual que la propuesta para los microservicios.
- **Otras**: Configuración de la nueva plataforma, discusión sobre calidad, perfiles técnicos y organización del equipo.
#### **Tareas #EBROA-103** (9 horas en total)
- **Revisión y adaptación a DDD**: Modificación y adaptación de la documentación de "Inside a Microservice" para alinearla con la estructura DDD. Documentación lista para revisión tras completar la adaptación.
#### **Tareas técnicas** (6.75 horas en total)
- **Actualización de `kubectl`**: Actualización de la herramienta `kubectl` y confección de la guía de desarrollo para el equipo.
- **Guía del Kafka CLI**: Trabajo continuado en la guía del Kafka CLI como parte de la documentación del desarrollador.
- **Revisión de la guía de `dbeaver`**: Lectura y revisión de la guía técnica sobre `dbeaver`.
- **Sección de Networking**: Actualización y trabajo en la sección de Networking dentro de la documentación del desarrollador.
- **Decisión de etiquetado en Runbooks**: Quitar el prefijo "[RunBook]" en los runbooks y usar una etiqueta en su lugar.
#### **Soporte y problemas** (2 horas en total)
- **Soporte al equipo de desarrollo**: Asistencia con la configuración de la VPN y acceso a Confluence.
- **Resolución de problemas de acceso a la VPN**: Solución de problemas de conexión.
- **Mantenimiento del equipo**: Actualización del sistema operativo.

### Resumen de logros:
- **Documentación técnica**: Finalización de la adaptación de la documentación "Inside a Microservice" a DDD, guía del Kafka CLI y Networking.
- **Mejoras en el equipo**: Decisiones sobre la organización de servicios batch y etiquetado en runbooks.
- **Soporte técnico**: Resolución de problemas de acceso y soporte en la configuración de herramientas críticas.

==========

## 23/09/2024

- **Reuniones:** (3 horas)
    - **Despliegue de microservicios en el nuevo entorno EBRO**: Participación en la reunión para discutir y revisar el proceso de despliegue de microservicios.
- **Tareas técnicas:** (2.5 horas)
    - **Documentación del desarrollador**: Trabajo en la guía del desarrollador, incluyendo la sección "how to call internal endpoints from localhost" y otros elementos de la guía.

## 24/09/2024

- **Reuniones:** (2 horas)
    - **Daily**: Coordinación de tareas y avances.
    - **Llamada con Javi**: Recibiste feedback sobre la documentación que estabas actualizando y continuaste haciendo ajustes en base a las observaciones.
- **Tareas técnicas:** (3.5 horas)
    - **Actualización de la documentación del desarrollador**

## 25/09/2024

- **Reuniones:**
    - **Daily** (9:30-10:00): Nada en concreto
    - **Daily CLI** (10:30-11:00): Nada en concreto
- **Tareas Técnicas y Documentación:**
    - **8:30-13:30:**
        - Documentación del desarrollador: Continuación del trabajo en la guía y ajustes necesarios para los desarrollos en el entorno EBRO.
- **Otros:**
    - **10:00-10:30:** Descanso
    - Reflexiones sobre el entorno EBRO:
        - Se plantea que cuando `product-brokers` vaya al entorno EBRO, se implemente con todo el pack de API-first, eventos en Avro y Schema Registry.
        - Es necesario priorizar este trabajo la semana que viene.
        - Revisión personal de la documentación actual para asegurar la alineación con estos objetivos.

## 26/09/2024

- **Reuniones:**
	- Daily (9:30-10:30): Nada en concreto
- **Tareas Técnicas y Documentación:**
	- **11:00-14:00:**
	    - Documentación del desarrollador: Leyendo toda la documentación actual de Kafka, recopilando información sobre lo que tenemos hecho para EBRO y Schema Registry, etc. 
	- **14:00-16:30:**
	    - Haciendo punto de situación sobre el soporte Avro y comenzando con la creación de tareas (apuntadas en un documento de texto)
	- **16:30-17:00:**
	    - Ordenando las tareas en el backlog de acuerdo con las notas tomadas
- Soporte
	- Ayuda a Álvaro con la creación de repositorio con los gherkins funcionales de `product-brokers`
- **Otros**
	- **10:30-11:00:**
	    - Descanso
	- **12:00-13:00:**
	    - Recogida de Alberto
	- **14:30-15:30:**
	    - Descanso comida

## 27/09/2024

- **Reuniones:**
    - **Daily** (9:30-10:00)
    - **Weekly** (10:00-11:00): Se plantearon las prioridades de trabajo para la próxima semana:
        - **Yo**:
            - Mover los módulos del starter de Kafka + Avro a `ebro-boot`.
            - Continuar con la documentación del desarrollador.
            - Crear las tareas pendientes de la lista confeccionada el día anterior.
        - **Jose**: Coordinar las reuniones de la próxima semana para reorganizar dominios, equipos, etc.
        - **Jorge**: Encargado de la parte de "inside a microservice", batch process, y la documentación de la nueva feature para generar controladores a partir de especificaciones de OpenAPI.
        - **Javi**: En temas relacionados con Java 21.
        - **Santi**: Despliegue del DataFlow, Jikkou, Schema Registry, schema publisher, y la consola de Redpanda.
- **Tareas Técnicas y Documentación:**
    - **12:00-12:30:**
        - Poniendo en orden las tareas de la lista.
    - **13:00-14:30:**
        - Finalización de la redacción del "inside a microservice" y afinando la redacción del "inside a batch".
        - Revisión completa del documento de "inside a batch".
- **Soporte:**
    - **12:30-13:00:**
        - Comentarios con Jose sobre el despliegue del automator y dudas sobre el cronograma para este despliegue.
- **Otros:**
    - **11:00-12:00:** Descanso



==========
### Informe semanal: 23/09/2024 - 27/09/2024

#### **Resumen de Avances:**
- **Documentación del Desarrollador**: Se avanzó significativamente en la actualización y creación de la documentación del desarrollador, incluyendo la finalización de "Inside a Microservice" y avances en la sección de "Inside a Batch".
- **Estructura de microservicios y despliegue**: Durante la semana, se participó en reuniones para coordinar el despliegue de microservicios en el entorno EBRO.
- **Planificación de prioridades**: En la reunión semanal se definieron las tareas prioritarias para la próxima semana, incluyendo la migración de los módulos de Kafka + Avro a `ebro-boot`.

==========
## 30/09/2024

- **Reuniones:** (1.5h)
    - **Daily** (9:30-10:00)
    - **Daily CLI** (10:30-11:00): Propuesta de utilizar el `automator` para testing del proyecto de `product-brokers`. Álvaro Mesa verificará la viabilidad técnica.
- **Tema de la metodología** (4h)
	- **Revisión de la documentación** sobre el "way of working" enviada por Iván. (12:00-14:30)
    - **Discusión con Iván** (14:30-15:30): Revisión y discusión del enfoque de la metodología "way of working".
    - **Discusión sobre la metodología** (16:30-17:00): Continuación del debate con el resto del equipo.
- **Tareas Técnicas y Documentación:** (1h)
    - **11:30-12:00:**
        - Finalización de la redacción del "inside a batch", dejándolo a la espera de feedback de Jorge Pacheco.
    - **17:00-17:30:**
        - Ajustes finales en "inside a batch" de acuerdo con el enfoque sugerido por Jorge.

==========

## Resumen mensual de septiembre 2024

### **Avances Significativos**

1. **Documentación Técnica:**
    - Se completó y revisó la documentación de "Inside a Microservice" y "Inside a Batch," con adaptaciones importantes para alinearse con DDD y la estructura interna de los microservicios en EBRO. 
    - Trabajo en la guía del desarrollador, particularmente en la sección de Kafka CLI, networking y cómo llamar a endpoints internos desde Kafka.
2. **Proyecto CLI:**
    - Se definió el alcance del MVP del proyecto CLI, enfocándose en el onboarding de préstamos y se inició la migración del código de `automator-cli` a `automator-launcher`.
    - Se completó la implementación del listener para eventos de baja de clientes y prospects y se verificó el flujo completo de creación de usuarios con verificación de mail.
3. **Organización y Metodología:**
    - Participación activa en la definición de la metodología "way of working," con la revisión de documentos internos y discusiones sobre enfoques más eficientes de trabajo en equipo, roles y responsabilidades.
    - Se propuso utilizar el `automator` para hacer testing en el proyecto de `product-brokers`.
4. **Plataforma y Despliegue:**
    - Se llevaron a cabo reuniones sobre el despliegue de microservicios en el entorno EBRO y la configuración del MVP en Bambú.
    - Instalación de herramientas actualizadas para entorno EBRO (aws cli, kubectl, ...).

#### **Tareas Pendientes y Follow-Up**

1. **Documentación:**
    - Revisar y finalizar la documentación del proceso de generación de código desde especificaciones OpenAPI.
    - Seguir avanzando en la guía del desarrollador para garantizar que los nuevos desarrollos estén correctamente documentados y alineados con la estructura interna.
2. **Coordinación del Proyecto CLI:**
    - Mantener seguimiento sobre la viabilidad técnica del `automator` en el proyecto `product-brokers` y asegurar que se coordinen las tareas de soporte y documentación requeridas.
    - Seguir con la migración de los módulos de Kafka + Avro a `ebro-boot` y verificar que el equipo continúe con las tareas planificadas.
3. **Gestión de Equipos y Organización:**
    - Revisar la división de equipos y dominios para la gestión eficiente del equipo de backend y aclarar roles en el nuevo contexto organizativo.
    - Hacer seguimiento de la coordinación con Jose para la reorganización de equipos, dominios y la planificación de reuniones clave la próxima semana.

#### **Tareas Pendientes:**

- Pasar a la gente la propuesta de "inside a mucriservuce"
- Añadir los links que ha puesto Jose en el chat de ¿?
- Echar un vistazo al diagrama
- ✅ Revisar la documentación del WoW que ha enviado Ivan
	- ⚡: Nos quedan más reuniones y charlas
- **Documentación del desarrollador**:
    - Continuar con la documentación del desarrollador para nuevos desarrollos.
    - ✅ **Continuar con la documentación del desarrollador**, incluyendo la revisión final de las secciones de "inside a microservice" y "inside a batch".
    - **Revisar la documentación** que Jorge va a preparar sobre la generación de controladores a partir de las especificaciones de OpenAPI y darle una revisión final.
- Jira
	- **Crear y organizar las tareas restantes** de la lista confeccionada el 26/09/2024.
- Soporte a Kafka + Avro
	- **Mover los módulos del starter de Kafka + Avro** a `ebro-boot`.
- **Despliegue y seguimiento**:
    - Estar atento al despliegue del onboarding de loans para poder desplegar el `automator`.
- **Implementación práctica**:
    - Implementar un ejemplo con lo nuevo del inside a microservice en uno o dos servicios de seguridad.
- **Organización y gestión de equipos**:
    - **Estar al tanto de las reuniones de reorganización de equipos y dominios** que Jose organizará la próxima semana.

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
	- En caso de que el proyecto tenga continuidad asegurada
- 💡♨️ Dar pasos hacia el continuous deployment
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY

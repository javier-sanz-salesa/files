# schema registry
## Decisiones
Lo primero: Quiénes tomamos esta decisión? Cómo y cuándo informamos al equipo de FR de esta decisión?

Damos luz verde a todo? Entiendo que depende del análisis a bajo nivel de lo que vamos a hacer
	- ¿Qué tipo de esquema vamos a utilizar? Mi voto va por Avro en formato .avsc
		- El motivo para no utilizar JSON Schema es que ya que el cambio va a ser significativo nos movemos a un formato binario
		- Protobuf tiene buena pinta pero no es la opción "nativa" de schema registry (sirve para otras cosas) y tiene un soporte más reducido.
		- El motivo para no utilizar .avidl es que es un paso adicional (schema registry trabaja con los avsc). Si la gente se acostumbra a trabajar con los avsc lo van a tener más fácil "hablando" con el registy.
	- Definir el nuevo modelo de trabajo -> Hay que estudiarlo a bajo nivel
	- Definir el modelo de convivencia y migración -> Depende del punto anterior
## Acciones
- Mirar la librería de arquitectura para ver qué cambios habría que hacer (<-- ~~Terminado~~ Queda mirarlo en detalle)
	- He mirado la librería, pero no sé qué cambios tendría que hacer (<-- Terminado. Hay que cambiar como la mitad de la librería)
- Tomar código de algún proyecto real para ver el uso que tiene esto (<-- Terminado)
- Necesito acceso al clúster de Kafka de los entornos (<- Terminado. Puedo acceder pero no tenemos instalado schema registry)
- Generar una nueva versión de la librería
	- Con esa versión de la librería confirmar que un servicio de los actuales sigue funcionando (PoC servicio actual)
	- Con esa versión de la librería tratar de migrar un productor y un consumidor clásicos (PoC migrar servicio)
	- Tratar de montar un consumidor y un productor desde cero (PoC servicio nuevo)


- Ver las posibles opciones para manejar los esquemas y las clases generadas
	- Comprobar la compatibilidad del esquema (esto sí o sí)
	- Opciones
		- Generar un artefacto
		- Que el plugin de maven hable con el schema registry para descargarse la última versión del esquema y generar las clases a partir de ahí
		- Que cada uno gestione sus archivos de esquema, se genere los esquemas en local y vaya al schema registry (o a otro sitio) para descargarlos a su proyecto local
	- Tomar la decisión junto con los demás

Cómo va a ser la experiencia de usar esto?
- Genero un esquema y lo añado a un repositorio
	- Un repositorio aparte? Unos archivos .avsc dentro del proyecto?
		- Dónde queda el asyncapi.yaml dentro de esto? --> Mirar las cosas que tengo de Inditex

## Otros
Vamos a tratar de juntar la parte esta con la propuesta que tienen en FR sobre ApiAsync

======

## Reunión decisiones Kafka

- Tipo de esquema a utilizar: avro. por qué no las otras
- Modos de compatibilidad: (backward/forward/both) (transitive/no)
- Metadatos en los mensajes: headers/envelope
- Particionado de topics: Hay que usar la key
- Modo de trabajo
	- Usar repo (similar a repo de ops pero para contracts)
		- Descripción
			- Se crea repositorio que contiene...
				- asyncapi.yaml
				- enlaces a archivos avsc
				- potencialmente otros archivos
			- Este repositorio tiene una build que hace las siguientes cosas
				- comprobaciones
					- correción: Julie? formato avsc? otros campos obligatorios?
					- compatibilidad del esquema
				- generación de jar conteniendo las clases correspondientes a los eventos
					- snapshots/releases
		- Ventajas/desventajas
			- (+) Nos da a arquitectura un control adicional
			- (+) Versionado semántico
			- (+) Todo en el mismo sitio
			- (+) Posibilidades de catálogo y documentación
			- (-) Es más complejo (hay que montar cosas)
		- clases repetidas y clases iguales diferente paqueteria <--- THIS
- Migración
	- Plan de migración
		- Hay que hacer un listado -> julie y repositorios
		- Vamos de productores a consumidores
		- TODO: Herramienta que analice los datos de Julie para sacar un plan?
		- Quién?
	- Cada artefacto
		- Se cambia a la nueva librería (P/C)
		- Se crea el repositorio interface/event (P)
		- Herramienta para sacar el esquema de avro del value (P)
		- Sacar el esquema de avro de la key (en base a la anotación actual de EventPartitionId) (P)
		- Se cambian los producers/consumers y se adaptan los tests (P/C)
- Documentación y catálogo
	- Usando la build del repositorio "api"
		- Comprobaciones cruzadas con los datos de Julie?
		- Generación de site

## Documento para Valiantys (ESP)

Nueva URL: https://confluence-orangebank.valiantys.net/display/DELIVARCH/Using+schema+for+events+and+way+of+working

====

Proposal of a new way of working so services that produce or consume events use a schema for messages in asynchronous communication.

1. Context

Prior to this proposal, another proposal had been made for the use of schema registry documented in the ES Confluence. On the other hand, a proposal had been presented by the FR team in order to add the possibility of documenting the events used in One Bank and the underlying structure of producers and consumers.

Therefore, it makes sense to do a little more complete work to take into account all the problems and think of a slightly more ambitious plan that includes all the possibilities that the use of schemes opens up.

2. Objectives

The objective of the proposed new way of working is multiple:

- Centralize the definition of the message format.
- Facilitate the evolution of these messages, making it difficult for errors to appear
- Add the ability to perform additional automatic checks in the process
- Add the ability to document the structure of producers and consumers of the architecture with data based on the reality of the system

3. Use of schema registry

More information can be found at https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/3458957402/1B+-+Kafka+Schema+Registry+adoption . The proposal is to use schema registry with Apache Avro, since it is the de facto standard for representing schemas in Kafka and has much greater adoption and support.

It is proposed to use the BACKWARD TRANSITIVE compatibility mode by default. Even so, it is necessary to highlight that this is a default mode that can be modified for any topic subject.

4. Architecture library

The changes required in the architecture library affect approximately half of its code and represent a paradigm shift with the current way of working.

The current library bases an important part of its functionality on the fact that classes are defined that represent the payload of each event using the @EventJournalType annotation and extending certain architecture classes. However, to work with Apache Avro, it is necessary to auto-generate the event classes from the schema. This makes our current approach invalid.

For this reason, a new architecture starter will be created to support the new event format. It is a less expensive solution and easier to maintain as there will be no services producing or consuming events in the new and old modes simultaneously.

Due to this paradigm shift it is necessary to make some changes to the way some core features of the library work. The list is not exhaustive and is subject to expansion:

- Features dependent on classes defined using the @EventJournalType annotation
- The metadata of the messages are now defined in the message headers. Previously they were included in the superclass of the class that represents the payload.
- Characteristics dependent on message metadata
- Topics partitioning will be done by directly defining the message key (possibly with some support from the architecture library). Previously, the key field was marked using the @EventJournalPartitionId annotation.

5. Way of working

Most of the changes focus on the way of working. Technical changes are simply the door that opens the possibility of making these changes in the way of working

5.1 "Interfaces" module in services

The services will have a new module that contains only the definition of the interfaces of that service. These definitions are initially those corresponding to Kafka events but could be extended later to their use in REST interfaces.

Said module would be included in the root level of the service repository or in parallel (at the -ops repositories level) (not decided yet).

The proposed structure is as follows:

```
interfaces-module/
|-- asyncapi.yml
|-- custom-future-file.yml
|-- (...)
`-- schemas/
  |-- user.avsc
  `-- address.avsc
```

The asyncapi.yml file defines, as before, the topics in which the service produces events with the following new features:
- Events are defined in .avsc files inside the "schemas" directory. These files are the ones that will be used to generate the avro classes, so they will be synchronized with reality
- Additionally we can start using the "publish" section to indicate which topics are being consumed. This information can be used to perform additional checks (this is discussed in detail a little later).

Schemas in avsc format contain the schema splitted in as many files as there are nested classes in the message structure.

5.2 Build "interfaces" module as a previous step

The "interfaces" module will have its own construction pipeline that will be built independently of the code belonging to said service. This build could in the future consist of the following steps:

5.2.1 Preliminary checks

- Verification against Julie data: It could be verified that the service has permissions to publish messages in its topic. If we also add consumer information in the asyncapi.yml file, we could also check the permissions to consume said topic and other issues such as verifying the name of the consumer group, etc.
- Verification that the scheme is correct and that it is also compatible.
- Any error during this step fails the build and forces the development team to solve the detected errors.

5.2.2 xxx-events artifact generation

If the checks are successful, a jar artifact will be generated with a name in the style of `service-name-events-X.X.X.jar`. This artifact would contain only the classes necessary to consume or emit events on a specific topic (classes that extend from `SpecificRecord`). These classes could contain references to architecture classes like the `Money` class or others that we want to provide as dictionary.

5.2.3 Generation of documentation site

With the information extracted from asyncapi.yml and that existing in Julie's repository, a documentation site could be kept updated that would be automatically aligned with the topics and events existing in the system, eliminating the need to "convince" the teams to keep their documentation up to date.

5.2.4 Other matters

- Breaking compatibility: When a service needs to start sending incompatible events you can use the **subject** of topics to effectively create different schemas in the same topic that don't have compatible schemas. It is necessary to give more detail to what this process would be like and to document it.
- Similarly today teams are sending different types of message through the same topic. In this case we will also use the subject to deserialize the messages correctly and check the correctness of the messages. We also need more detail here for perhaps we need to implement a deserializer in the architecture level.
- Work with SNAPSHOTs/RELEASES: The "interfaces" repository will have different branches. The develop branch will generate a -SNAPSHOT artifact. The master branch will build the version without any suffixes.
- The schema registry of the development environment will be accessible through API to the development team to be able to delete the schemas of the topic with which they are working at a given moment.

6. Necessary actions

Need still more detail here.

6.1. Architecture

- Development of a new architecture starter
- "Interfaces" artifact generation pipeline
- Documentation of the migration process (step by step guide)
- Direct support to teams

Non-essential tasks should perhaps be left for later from the MVP

- Checks on Julie about the producers
- Add the consumers in the `asyncapi.yml` file and check in Julie
- Generation of documentation site

5.2 Teams

- Migration with the support of the architecture team
- The order must always be the producers first and then the consumers
ivan gonzalez suarez (PO: Monica Lopez) -> cards
javier fernandez babin(PO: Rafael Sanchez) -> payments
jorge pacheco mengual -> daily banking (accounts)
juanjo maldonado illescas -> savings
antoine ¿pourriot? -> djingo
alberto segovia sanz(PO: guillaume de rouze ) -> customer care
jose luis pumarega -> onboarding / ¿notifications?
alexander quiroga -> risk/aml
montassar el bahi-> gb plus
hakim medadjelia -> premium pack
## 10/01/2024

- Entrevista con Kevin Sebastian (Lognext)
	- Impresiones en documento correspondiente
- Toda la tarde con el problema que tengo con los tests del `cards-daily-reports-batch-processor`
	- Parece ser que unas veces funciona y otras no
		- Sólo en caso de que añada el starter de convention-test? --> Probarlo
	- Las veces que funciona parece estar leyendo menos archivos (5) que las que no funciona (17)
		- Aquí puede estar la clave

==========

## 15/01/2024

- Pido permisos en el espacio de SEPA Payments para crear la estructura de documentación
	- Cambio toda la estructura de documentación en base a lo que hemos hablado
- Pido la creación de una lista de correo para backend
	- Hecho
- Convoco el Miércoles para la charla de Java 17

## 16/01/2024

- Creo la lista de distribución de correo "backend" con toda la gente de backend
- Actualizo y cambio los owners de la lista "es-architecture" con los miembros de arquitectura
- Correo respondido a Ainhoa pidiendo la incorporación de Victor.
- #DPA-1833
	- Pruebo la solución que me dio Jose Manuel para que los batches no se auto-ejecuten. No parece que funcione
	- Modifico el test del proyecto que falla para que imprima el nombre y la clase de todos los beans de su contexto
		- En el que no funciona se están cargando los beans del starter de REST
			- Acción: Elimino la dependencia con el starter de REST
	- Sigue fallando y carga exactamente los mismos beans que el ejemplo que si funciona, por lo que ha de ser forzosamente un tema de concurrencia
		- Voy a ver si puedo hacer tests comparativos
			- Fallan 14/20 con la dependencia
			- Salen bien todos sin ella

## 17/01/2024

- Le comento a David el marrón de la iniciativa de documentación
- Charla de Java17
	- No puedo incluirla en Tech Talks
		- Pido acceso a la página
	- No encuentro una forma de compartir archivos con gente externa pero que trabaje aquí
		- Deberían tener un grupo, pero no parecen tenerlo. Le pregunto a Pedro
			- No me responde
- #DPA-1833 
	- Sigo con esto. Voy a ver qué pasa si ignoras todos los tests
		- En ese caso funciona (he hecho 6 ejecuciones)

## 18/01/2024

- Comparto el video de la charla de Javi
	- Lo meto en `Deliver IT Commons`
- IT Sync
	- Tema de la documentación
- Tema de LogNext y Victor Cumana
	- Reunión
-  #DPA-1833 
	- Intuyo que el fallo ocurre cuando el test de convención se ejecuta antes que el de FileJobProcessor (el de documentacion no pasa nada)
	- Conclusiones
		- Cuando no funciona es porque ya se ha lanzado un job antes similar, por lo que aparece una excepción del tipo `JobInstanceAlreadyCompleteException`
		- Los eventos se están produciendo y se consumen, pero el bucle del awaitility no está haciendo el polling en el consumer
		- ¿Es posible que sí fuera lo que dijo Jose Manuel pero por algún motivo no lo hicieramos bien?
			- Cambio el test de convención para que ponga spring.batch.job.enabled a false y parece que no le hace caso porque siguen saliendo excepciones `JobInstanceAlreadyCompleteException`
				- TODO: Comprobar el valor que llega realmente al test

## 19/01/2024
- 2 horas de daily / weekly
- #DPA-1833 
	- Ya sé lo que pasa. El proyecto NO es un batch. Es un job de spring integration que nada más levantarse verifica los archivos que hay y lanza jobs. Falla porque esto ocurre siempre. He hecho fallar los tests poniendo un sleep en el de la documentación
		- Pensar soluciones: TODO

==========

## 22/01/2024

- Entrevista con Julio
	- Muy bien todo. Me gusta. Por mí no buscamos más, ya que el otro candidato que teníamos ahora mismo nos ha fallado
- #DPA-1833 
	- Voy a ver cómo funciona la propiedad `orangebank.boot.batch.sftp.polling.autoStartup`
		- Consigo parar el polling, pero sigue fallando
	- El problema es que cada test crea un `@KafkaListener` y ese listener se queda escuchando el topic, por lo que subsiguentes tests no reciben nada, por lo que hay que cambiar la política con la que funcionan estos tests

## 23/01/2024

- Hablo con Nico para decirle que ok con la incorporación de Julio
	- Correo enviado a Ainhoa, de LogNext
		- TODO: Esperando respuesta
- Reunión "validaciones"
	- Existen una serie de herramientas que está desarrollando QA y se va a trabajar en ellas para que estén disponibles de cara a los POs y a los equipos próximamente
	- Hablar con los TLs para agendar una reunión y comentar el episodio este de las regresiones (en principio decir que queremos hablar de las funcionalidades previstas por los equipos)
		- La idea es montar una reunión con Yo, Nico, el QA del equipo, TL y backend cada sprint antes de la planning del siguiente
			- Intención: 
				- Dar seguimiento a las regresiones que haya podido dar QA (que los errores no sólo se corrijan sino que se implementen los tests que sean necesarios)
				- Hablar de mejoras, etc (¿?) en calidad
	- Nico se va a pegar con el comité de dirección para esto
- Reunión con Yair
	- Las mejoras van a ir a través de los TL, que tienen poder de impulsarlas a través de su conversación con el PO
	- El tema de la calidad va a ser el QA de cada equipo. Cada defecto que se detecte tiene que incluir en su ciclo la adición de pruebas e2e, o tests del tipo que sean necesarios
	- Incidente con la release
		- Vieron temas con el servicio de bizum, por lo que echaron la release para atrás y ya tienen tareas para solucionarlo
- Reunión con David
	- Lo mismo y...
	- Tests e2e en el pipeline
	- No parar toda una release porque haya partes que están mal. Seguimos adelante con lo que está bien.
	- Incidente con la release
		- ¿?
- Reunión con Arturo
	- Incidente con la release
		- Hubo temas en SalesForce
- Reunión con Javi Casado
	- Hubo una equivocación que salió en temas de e2e. Se actuó rápido y no hay demasiado problema
- Reunión con Nico
	- TODO: A la espera de que convoque con la gente de QA para dar seguimiento a los incidentes

## 24/01/2024

- Convoco reunión mañana para hablar de la propuesta para el seguimiento de incidencias
	- El QA de cada equipo las registra como imagino se estaba haciendo hasta ahora
	- Como parte de la resolución de esa incidencia, se añaden tests o procedimientos al despliegue por parte del equipo.
	- Esto genera una tarea que ha de pasar al backlog del equipo, a ser posible para el siguiente sprint.
	- Reunión de seguimiento durante al menos las primeras entregas. La menor cantidad de gente posible.
- Arreglo los tests del `cards-daily-reports-batch-processor`
	- Me cargo la build por el problema este que tienen con bitbucket
	- Al final la vuelvo a dejar funcionando

## 25/01/2024

- Reunión temas de calidad
	- Enviar un resumen con lo que se ha hablado
		- Hecho y convocada la reunión
- IT Sync
	- Menciono lo de la nueva documentación
		- Generar el draft bien (HECHO)
- Reunión de revisión de la estructura de documentación
	- Nos presentan la nueva estructura para la parte funcional -> ok
		- Hay que incluirla en el DRAFT: La tarea de antes (HECHO)
	- Tema de los Runbooks
		- Lo añado en el documento

## 26/01/2024

- Documentación
	- Creando el outline con todo lo de seguridad

==========

## 29/01/2024

- Chapter sync
	- Udemy, O'Reilly: cursos "de ejemplo"
		- hecho
	- Comentar a los TL lo de las incidencias y lo de la documentación
		- Hecho
	- Incorporación de Julio: lo lleva Nuria
		- Le he pasado los datos
	- Tema de estimaciones: hablar con Joaquín
		- Ya me dirá si es necesario
- Me reúno con Morgan y Chincho para explicar el tema de la documentación
- #DPA-1833 
	- Voy haciendo más pruebas
		- Encuentro un problema con `tpv-conciliate-batch` pero parece que el causante es el propio servicio, que se ejecuta mal de forma aleatoria

## 30/01/2024

- #DPA-1833 
	- Añado algunas mejoras
		- Hacer que las que tienen el profile @Test en los controllers no fallen
		- Cambiando el mensaje para que sea más legible




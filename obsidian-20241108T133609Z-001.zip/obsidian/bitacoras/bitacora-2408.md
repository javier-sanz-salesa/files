## 05/08/2024

- R: Daily
	- ⚡ Ha salido una tarea sobre coger el sftp to s3 sync y tratar de generalizarlo y, ya de paso, eliminar spring integration
- R: CLI
	- ⚡ Tengo que leerme la documentación y mirar el código para comprender qué están haciendo
		- Cosas que veo
			- Algunos smells
				- A alto nivel
					- Todo en un único microservicio. ¿No deberíamos dividir en casos de uso + tools?
					- No hay documentación en absoluto
					- No hay tareas dignas de tal nombre
					- Se están usando los acceptance tests para probar el propio automator
				- A bajo nivel
					- Código no muy bien estructurado en cuanto a paquetes y dependencias
					- No se usa mapstruct, lombok en donde se puede
					- Uso de asserts de java
- Aplicando parches y actualizaciones para que me funcione la VPN
- Actualizo ob-boot a la 3.0.0 y construyo
- Me bajo todos los proyectos de `ebro-architecture`
- R: Bambu MVP Setup
	- ~~⚡~~ Mirar las tareas de "create Kafka topics". Están en el camino crítico pero no sé quién va a hacerlo
		- ⭕ No encuentro mucho, pero veo que está planificado para Septiembre así que de momento no voy a preocuparme

## 06/08/2024

- R: Temas de la CLI
	- Estructura básica del automator y aquello que le acompaña
		- Tools: Endpoints de tipo test que se encarguen fundamentalmente del "given" y del "then" en los use cases
			- Pueden ir en los endpoints con perfil test o en servicios totalmente aparte
				- Si van en servicios aparte es más complejo de mantener (proclive a fallos de integración)
				- Si van en los propios servicios ensuciamos el código de los mismos
		- Automator: Servicio (o servicios) que sirven para lanzar los casos de uso
			- Expone los siguientes endpoints
				- Preparación de datos
				- Lectura de datos
				- Recepción de eventos
		- Playwright
			- Es el que ejecuta los tests pasando desde el front
			- Hay una funcionalidad que llama a APIs directamente
- R: Refinamiento de FPV
	- No es refinamiento, sino que es el equipo de UX mostrándonos las ventanas que están preparando
- R: con Nico, Oscar, Phoebis, D.Bijleveld
	- No se qué del mock que se está montando para loans
		- Es necesario que el mock de ElectronicID nos devuelva DNIs de una lista específica (ahora es aleatorio)
		- El motivo es porque loans-promotions ha de tener ese DNI en su lista de preaprobados
		- No comprendo bien el flujo actual de esto
			- loans-onboarding
			- loans-promotions
			- fronts?
				- ⚡ Investigar cómo funciona esto
- R: con Nico
	- Sería buena idea hacer 1 on 1 con la gente de backend
		- No estaría mal sincronizarse con Chudo 5 minutos para ver qué está preguntando, etc
	- Ivan va a ser el responsable de esto

## 08/08/2024

- Tratando de ejecutar el `automator-cli` igual que nuestros tests de aceptación
	- Creo que hay que mover las clases a `src/test/java`
- R: Refinamos el framework e2e
	- Todo OK. Los puntos son estos
		- Los tests se pueden ejecutar de forma programada
		- Los tests se puedan ejecutar desde una web a demanda
		- Se puede parametrizar qué tests se van a ejecutar
		- La definición de los tests está en lenguaje Gherkin
		- Los tests son end to end
		   - Se preparan datos a través del automator backend (para ello se utiliza el cliente api de Playwright)
		   - Se opera la feature a través del front (usando Playwright)
		   - Potencialmente se hacen otras operaciones a través del automator backend como limpiezas u otras comprobaciones más avanzadas
	   - Preguntas
		   - ¿Cómo se ejecutan los tests?
			   - En principio se ejecutan con `mvn test`
		   - ¿Qué artefactos vamos a tener y de qué se va a encargar cada uno?
			   - `automator-launcher`: contiene los tests de aceptación, la integración con PlayWright y las llamadas al automator backend. Es el que se ejecuta en el pipeline
			   - `automator`: es el backend que ejecuta sobre todo la preparación de los datos de prueba
		   - ¿Qué casos de uso vamos a implementar (propuesta)?
			   - Ya tenemos en marcha el get user y el validate email
			   - Hacer el onboarding es overkill y no merece la pena
			   - Meter un par de casos de uso más
				   - Algo que use Mambú?
				   - Algún ejemplo en las tools que hemos hecho de meter cosas que hoy en día están en el CLI?
	   - Otros temas
		   - Móvil
			   - PlayWright no tiene nada para móviles. Si en algún momento nos vamos a probar cosas con móvil habrá que ver qué se hace
		   - Terceros?
			   - En el entorno de desarrollo ya existen entornos de test de esos terceros o bien hay mocks. Hay que añadir tools (endpoints en el automator backend) que permitan interactuar con ellos

## 09/08/2024

- R: Daily CLI Team
	- Caos. Me estoy agobiando por la cantidad de cosas que desconozco y no sé por dónde tirar
		- Por un lado vamos a centrarnos en hacer un create user / get user y que esto funcione en el pipeline
			- Bajarse las piezas del automator y ver por dónde se puede tirar
				- `automator-launcher` ejecuta unos tests vacíos en el pipeline (un poco lo que yo estaba haciendo con `automator-cli`)
				- `automator` tiene varias cosas
					- verificación de email: esto verifica que un email tiene un token en una base de datos local (¿?)
						- ¿A quién está dando servicio esto?
					- create user: vacío
						- Realmente es lo que deberíamos estar exponiendo. Continuar por aquí
					- getUser: Se autentica con el jwt-generator y obtiene desde people un usuario
						- Esto es lo que se debería hacer desde el playwright, por lo que hay aquí una labor de montarse algo en el `automator-launcher` que llame a esto
		- Por otro, hay que hacer el onboarding de loans
		- Gestión. Tareas? Algo?
- #CLI-5:
	- Hablo con Alberto y me voy a coger yo la tarea de implementar un action en el `automator` que sirva para crear un usuario
	- Me voy a basar en lo que hay en `qa/e2eframework` (para esto y para otras cosas)
		- Me lo bajo y entro en `cli.ts`
		- Secuencia del `cliCreateUser.ts`
			- Se rellenan unos datos básicos y se envía un email
			- Se busca el token haciendo consultas en Kibana
			- Se rellenan otra serie de datos
			- Se crean los mocks de imagen y video para eid
			- Se obtiene el access token utilizando email, número de teléfono y token del mail
				- Se registra el email -> /onboarding/email/${token}/EMAIL_REGISTRY
				- Se verifica el teléfono -> /onboarding/otp
				- Se busca el OTP en Kibana
				- Se verifica la OTP -> /onboarding/phonenumber
				- Autorización (obtener el access_token)
					- /session/mfa-sms/authorize
					- /session/mfa-sms/oauth/token
			- Me quedo en `createDNIProspects.ts:63`
			- (...) Proceso de verificación de identidad con electronicID

==========

## 12/08/2024

- Sigo mirando el código de `cliCreateUser.ts`
	- A continuación viene la verificación de electronicId, la validación por parte del agente. Son procesos muy complejos. y casi todos van dentro de bucles por si los fallos.
	- Se va moviendo el proceso por una máquina de estados llamando a `/onboarding/step`
	- Se piden las evidencias en el endpoint `(POST) /onboarding/v1/evidences/sessions` (no estoy seguro de qué es esto) -> Devuelve `authorization`
	- Se utiliza ese `authorization` y los mocks de las imágenes para subir la info a ElectronicID. Eso devuelve un `videoId`
	- Se envían las evidencias de EID con el endpoint `(POST) /onboarding/v1/evidences` con el `videoId` dentro del campo `sessionId`. En este caso no tiene valor el campo `fiscalDocumentNumber`.
	- Se realiza el proceso de la conexión del agente para validar el usuario
	- Se vuelve a hacer un `PATCH` de los datos del usuario con algunos valores que pueden haber sufrido modificaciones con `/people/me`
	- Se firma el precontrato llamando a `(POST) /products/consents`
	- Se firman los "people consents" (`THIRD_PARTY_ADS`, `DATA_SHARING`, `EXTERNAL_DATA_SOUCES`) llamando a un patch sobre `/people/me`
	- Se llama a los "clearance checks" con `POST /onboarding/clearance/checks`
	- Se firma el contrato con un `offerId` que está a fuego. Llamamos a `(POST) /products/v2/contracts` y devolvemos un `id` (¿de contrato?)
	- Se obtiene el `requestId` de ese `id` de contrato con `(POST) /products/contracts/{id}/request`
	- Al final devolvemos...
		- `accessToken`, que hemos ido utilizando para autenticarnos en las llamadas
		- `requestId`, que es el identificador de esa request sobre ese contrato (¿?)
		- `id`, que es el identificador de ese contrato
	- Esto se mete en una estructura que se llama `prospectData`
	- Se llama a `createCustomer` y se devuelve su UUID
		- El `OTPCode` se puede pasar por consola o, por defecto, es "012345"
		- Primero se llama a `signContract`, que tira un `(POST) /products/contracts/{useruuid}/sign` con el `OTPCode` y el `requestId`
		- Luego se llama a `(POST) /operational-identities/me/credentials` para setear el password del usuario
		- Se recupera el usuario con `(GET) /people/me`
	- Se hace algo relacionado con sustituir el teléfono con un `fakePhone`
	- Se hace un `getPersonData` utilizando el teléfono utilizando un endpoint `/admin` (este cliente se está creando de forma diferente)
	- Al final, en caso de que el cliente se haya creado como PROSPECT (`dataUser.type === 'PROSPECT'`), se puede borrar
		- Se obtiene un header de impersonación llamando al JWT Generator
		- Se llama a `(DELETE) /people/prospect`
- Comienzo la implementación
	- Me pongo a crear un usuario a capón

## 13/08/2024

- x

## 14/08/2024

- R: c/ Nico
	- Encontrar algún template engine para hacer el front de la CLI (nos falta capacidad en frontend)
		- ✅: Le paso lista de candidatos a Nico. Básicamente Thymeleaf, Handlebars.java y Pebble
	- El modelo "JWT Generator" y "Consola de dominio" cuenta con problemas en el sentido de que hay que abrir puertos
		- No entiendo muy bien estas cosas. Consultarlas con Álvaro
	- Hay que poner a gente que está desocupada a hacer cosas. Ideas
		- Trabajar en la parte CLI, que ahora puede ser una webapp
		- ¿Apoyo en seguridad?
		- ¿?
- R: Daily Arquitectura
- R: Daily CLI
- R: c/ Joaquín, Álvaro
	- Necesidades en el equipo de arquitectura seguridad
	- Es necesario ASAP una persona apoyando aquí
	- La idea es que sea a largo plazo
	- De momento no tenemos abierta la posibilidad de contratación, pero sería interesante más adelante
	- ⚡: Álvaro nos va a pasar una lista de candidatos
		- Yo: David Bijleveld??
- R: c/ David
	- Plantea que el modo de compatibilidad del schema registry debería ser FORWARD_TRANSITIVE y no BACKWARD_TRANSITIVE como habíamos planteado en principio
	- ⚡ Mirar la documentación que generamos en su momento y repasar las razones de lo que habíamos dicho en un primer momento.
		- ✅ Le envío un mensaje a David en el que me decanto por `BACKWARD_TRANSITIVE`

## 15/08/2024

- Festivo

## 16/08/2024

- R: Weekly
	- Quedamos en que las alternativas para elegir entre `BACKWARD_TRANSITIVE` y `FORWARD_TRANSITIVE` son
		- Nos gusta `FORWARD_TRANSITIVE` por eliminar dependencias pero hay que ver qué ocurre en caso de un reconsumo
		- En caso de que lo que encontremos no sea satisfactorio, nos tendremos que ir a `BACKWARD_TRANSITIVE`
- #CLI-5 
	- Mirando la mejor manera de hacer un bucle de espera por el mail
		- Awaitility está pensado para scope test
		- Utilizar futuros es un tanto rústico y un poco overkill. Se puede hacer incluso que al recibir el email se complete el futuro.
		- Spring Retry, Resilience4j o Reactor es matar moscas a cañonazos
		- Creo que me voy a quedar con la librería `dev.failsafe:failsafe`
		- Me quedo implementando correctamente el método de espera (casi lo tengo)

==========

## 19/08/2024

- Hoy:
	- Terminar la implementación del bucle de espera de #CLI-5 
	- ✅ Leer las buenas prácticas de schema registry
		- Es bueno saber que existe esta herramienta pero me parece sobrecomplicar los esquemas (sintaxis, etc)
- R: Daily
- R: Daily CLI
	- Dificultades para organizar las tools, etc
- R: c/Álvaro: Lista de candidatos para apoyar a arquitectura
	- Lista de candidatos para apoyar el equipo de arquitectura de seguridad
		- Carlos García -> +
		- Yair -> Conflicto?
		- Guetón -> De baja
		- Pacheco -> A Arquitectura
		- Oscar -> ?
		- Sergio Verde -> ?
		- J Torres -> Demasiado discreto?
		- D. Bijleveld -> No estoy seguro
	- ⚡ Lo dejamos para cuando vuelva Joaquín. La opción obvia es Carlos, pero no es una opción a largo plazo
- R: c/Carlos: Puesta al día
	- Cosas en las que estamos cada uno
		- Yo: CLI, otras
		- Álvaro: Temas de migración de artefactos etc
		- David: Tema de Helm Charts de schema registry, etc
	- No puedo hablar con él porque tiene problemas de conectividad
	- ✅ Le sugiero que tome la tarea de EBROA-10, a la que sólo le quedan algunos flecos
- R: Bambú MVP Setup
	- ✅ Tenemos una tarea que se está yendo de tiempos (EBROA-56) pero nos falta el conocimiento para continuarla porque los que nos hemos quedado esta semana somos unos paquetes
		- Hablar con Carlos para ver quién se puede poner con ello
		- Carlos se responsabiliza de ello y se lo comento a Chudo
	- ✅ Hay unos temas que tiene que responder David en el chat del MVP
		- David tiene que dar un update sobre "Kafka topic setup"
			- Lo da
		- David tiene que decir si se puede apagar el Kafka en modo KRaft que hay desplegado en el entorno de INT
			- Es un tema del DL
- #CLI-5 
	- Termino de implementar el código
	- Faltan tests unitarios
	- Me cargo los tests de aceptación pero es porque me los he cargado al desactivar el consumidor
		- ⚡ TODO: Arreglarlos
		- No consigo hacer un sólo test unitario porque estoy muy cansado y no puedo concentrarme.

## 20/08/2024

- #CLI-5 
	- Implementando los tests unitarios
	- ...

## 21/08/2024

- #CLI-5 
	- Termino los unit tests
	- Mergeo con lo que está haciendo Juanra
	- Me he cargado el email verification
		- El que ya había asume que simplemente escuchamos el topic de mail y tenemos una proyección del mismo
		- El que he hecho yo crea la entrada en base de datos cuando creamos y luego escucha las verificaciones para hacer un update
		- ✅ Arreglado
	- Temas de sonar, de cobertura, de lombok+sonar...
	- Consigo desplegar en DEV
	- Mañana:
		- Probar que esto funciona e implementar más tests

## 22/08/2024

- #CLI-5 
	- Probando que puedo llamar al endpoint que estoy desarrollando y que deja alguna traza en Kibana
		- Ver si puedo llegar al `/health` (faltaba el header host)
		- Llego pero no tengo permisos para llamar a onboarding
		- Se los pido a Álvaro
		- Me falta un header "origin". Lo pongo
	- Se llama al servicio de onboarding, lo que pasa es que el mail está desactivado
		- Quiero saber en qué parte se genera el registration link, para saber si esto se está devolviendo o algo
			- Se llama a `(POST) channel-verification/v2/email` para registrar el email y este te devuelve un token
				- Esto quiere decir que <u>no se va a enviar un evento con el email</u> si tenemos desactivado lo del correo
					- ⚡ Podríamos reactivarlo para probar que funciona?
					- ⚡ Deberíamos meter un flag para desactivar la espera por el evento. Es una pena porque no comprobaremos si funciona el envío de email
				- ⚡ Comprobar si se está registrando algo en este caso para ver si podemos hacer un getuserinfo o algo
					- Se crea el prospect cuando se llama a `onboarding/email/{emailToken}/{scope}`
				- ⚡ Se puede autenticar con rol ADMIN y llamar a `(GET) people/{personId}` para obtener la información del prospect
					- ¿Cómo se autentica uno con este rol?
						- En el despliegue se está inyectando en todos los sitios `ORANGEBANK_BOOT_INTERNAL_AUTH_ADMIN_USERNAME` y su correspondiente password

## 23/08/2024

- #CLI-5 
	- Reorganizando el código para que tenga sentido
		- Termino y añado docu
		- ⚡ EL lunes: ver si han pasado los pipelines!!

==========

## 26/08/2024

- x

## 27/08/2024

- #CLI-5 :
	- Refactorizando el tema de la obtención del mail para añadir un feature flag
- Tema de que los OCSP no funcionan a través de Firefox dentro de la VPN
	- Pongo un comentario en el ticket https://obkesp.atlassian.net/jira/servicedesk/projects/OBS/issues/OBS-49668

## 28/08/2024

- R: Daily
- R: Daily CLI
- R: Transpaso de conocimientos de David
	- Se graba y se mete en una carpeta dentro de "Deliver IT Commons" > Formacion > Arquitectura
- #CLI-5 :
	- Añado el person a crear dentro del API y despliego
	- Comienzo a construir la llamada al adminGetPersonInfo
		- Busco un ejemplo: Lo encuentro en `adjustments`
		- Construyo el `@FeignClient`
		- Tengo que mapear la bastante compleja request que me llegará desde people. De momento quizá puedo obviar los mapas.

## 29/08/2024

- ⚡: Migrar el developers handbook (maven, docker)
- #CLI-5 :
	- Haciendo la llamada al `adminGetPersonInfo`
		- Me doy cuenta de que no puedo utilizar ese dato porque todavía no tengo el id de usuario (tengo que completar la verificación del móvil)
	- Refactorizo las clases con la información del usuario
	- Comienzo a crear un listener de people para ver cuándo se crea el prospect (más sencillo y fiable de momento ya que hasta que no tenga un access token no puedo obtener el user id)
		- ⚡: Crear el KafkaListener que llama al `TemporalCustomerCreationUpdater` (pensar un nombre mejor). Escuchar los eventos de PersonCreated y PersonUpdated

## 30/08/2024

- #CLI-5 :
	- Consigo hacer el KafkaListener, el mapper y el findByEmail
	- Cuando ejecuto los tests por algún motivo no se crean los topics
		- Fallo tonto
	- ⚡: Seguir con el bucle de espera del PersonCreator
- ⚡: No olvidarse de lo de la documentación! ( #EBRO-99 )

==========
## Pendientes

- Ver los equipos que vamos a montar
	- ¿Nos fijamos en Bian?
	- ¿Qué pasa con la gente esa que supuestamente va a entrar de Hiberus?
	- Hay que seguir mirando BIAN + el event storming de Financiacion punto de venta
		- De este modo iremos viendo los equipos que necesitamos
- ⚡Terminar de barrer el tablón actual de DPA para moverlo al de EBROA
	- 🚫 Necesito permisos de administración de ese tablón
- Tema #DPA-1664 
	- ⚡ Ir implantando lo de los convention tests

## Seguimiento

- ⚡ Tema de los permisos en confluence
	- 📆 El **4 de Abril** vuelve Julián de vacaciones. Seguimos empujando con esto
	- El 9 de Abril vuelvo a preguntar en el chat
- ⚡ Mejoras en el way of working
	- Hablar con Ivan

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
	- En caso de que el proyecto tenga continuidad asegurada
- 💡♨️ Dar pasos hacia el continuous deployment
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY

AIHA-3790: Dar de baja un usuario
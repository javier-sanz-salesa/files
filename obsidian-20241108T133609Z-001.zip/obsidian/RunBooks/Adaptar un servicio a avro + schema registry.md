- Generar el archivo AVSC para los eventos que vamos a enviar (producer)
	- Opciones
		- `kafka-schema-registry-maven-plugin`
			- Usar el test que, junto con EasyRandom y Jackson,  te crea los objetos correspondientes
			- Añadir la configuración del plugin en el app
```xml
<plugin>
	<groupId>io.confluent</groupId>
	<artifactId>kafka-schema-registry-maven-plugin</artifactId>
	<version>7.6.1</version>
	<configuration>
		<messagePath>src/test/resources/GenerateRevolvingMonthlyStatementPayload.json</messagePath>
		<schemaType>avro</schemaType>
		<outputPath>src/test/resources/GenerateRevolvingMonthlyStatementPayload.avsc</outputPath>
	</configuration>
</plugin>
`

## 02/02/2024

- Weekly
	- Tema del versionado semántico
		- Creada tarea https://obkesp.atlassian.net/browse/DPA-1961
	- Tema de los permisos, etc
		- Pedidos. A la espera de recibir más
	- Tema del deprecado de endpoints
		- Enviado el mensaje a los TLs
		- TODO: Hacer una búsqueda yo
		- Revisar la PR de Jose para este tema en el cliente de Mambú
			- ok
	- Tema de más esfuerzo en la documentación
		- Pedir permiso para más gente
	- Tema de vamos a hacer lo mismo en arquitectura (con el confluence)
		- Me encargo yo
			- No me da tiempo

==========

## 05/02/2024

- Tema de la deprecación de endpoints de Mambú
	- Recopilada la información y presentada a los squads
	- A la espera de recibir por parte de Diego la confirmación de que el streaming api no está incluido

## 06/02/2024

- Reunión sobre costes y movidas de migración a 'maple'

## 07/02/2024

- Colocando la documentación de arquitectura
	- Peticiones de permisos a páginas que están restringidas dentro de nuestro propio espacio
		- Aún sin respuesta
- Documentación:
	- Pidiendo permisos
- R: Documentación en SF
- R: Seguimiento de incidencias en RT
- R: Con Yair y Álvaro de Mesa
	- Hablamos del proceso de seguimiento de incidencias
		- El ticket lo crea el que lo descubre (normalmente el QA del equipo)
		- El QA del equipo le da seguimiento e intenta que este trabajo entre en los sprint
		- No se cierra hasta que este trabajo se haga (añadir tests, cambiar procesos, ...)
		- Escalará en caso de que se acumule demasiado trabajo
	- Creamos un ticket (PYC-1082) para dar seguimiento al tema de calidad con el incidente

## 08/02/2024

- Confusión con los permisos de CC
	- Pedido a Julian
- Firmada documentación formación compliance penal
- IT Sync
	- Tema de Mambú (queda pendiente hasta al menos 15 días)
- Tema de la documentación
	- Recopilando a gente y pidiendo permisos
	- Pedido link a la gente de los chapters
Hoy
- doc chapters
- codigo?

==========

## 12/02/2024

- #DPA-1833 
	- Hecho merge
	- Documentación

## 13/02/2024

- XXX

## 14/02/2024

- #DPA-1833 
	- PRs para eliminar el tema de los convention tests

## 15/02/2024

- #DPA-1966
	- Haciendo repaso de los endpoints deprecados en Mambú
	- Esperando: Permisos de administración del API de setup de Mambú (hay que hablar con Jose Manuel y con Diego Almazán)
- Viendo lo que hay en https://bitbucket.org/obkesp/workspace/projects/CHBCK
	- Hay utilidades varias que sinceramente no me parecen prioritarias
- #DPA-1733 : Spike de AsyncAPI, Avro y Schema Registry
	- Consulta del ADR específico que teníamos
	- Escribiendo cosas

## 16/02/2024

- #DPA-1733 
	- Montando en local todo el tinglado para hacer una PoC con el `sandbox`

==========

## 19/02/2024

- ramiro rivas ->> e2e code
- #DPA-1733 
	- Montado todo en local para que produzca y consuma avro
	- No puedo configurar KafDrop para visualizar specific record

## 20/02/2024

 - #DPA-1733 Empiezo a mirar herramientas para generar esquemas avro a partir de clases Java
 - Reunión en la que nos hablan de los planes evolutivos para el software de apoyo (e2e tests, cli, ...)
	 - No tengo muy claro de qué hablan

## 21/02/2024

- #DPA-1733 
	- Descarto el uso del deserializador de Jakson para avro. No es lo suficientemente personalizable
	- Descubro el goal `induce` del `avro-maven-plugin`. Usando algunas personalizaciones se puede hacer una herramienta bastante útil
- Reunión de calidad en RT
	- Iniciativa de seguimiento de incidencias en RT
		- No se ha priorizado ninguna de las tarjetas que se crearon
		- Nadie quiere hacerse cargo de crearlas
		- Nadie quiere responsabilizarse de ellas
		- Mi propuesta: Dejemos de hacerlo y ya
	- Tema del backlog del squad de Banking
		- Ivan Morales va a juntarse con ellos la semana que viene y va a hacer retrospectiva

## 22/02/2024

- Reunión sobre evolución del software de QA (e2e framework, CLI, ...)
	- Me pongo a mirar lo que hay para tener cierta idea de lo que vamos a hablar
	- Damos varias opciones y quedamos en que vamos a hacer un ejemplo utilizando el `sandbox` para ver las diferentes opciones
		- ¿Quién?
	- Convocan un event storming para la semana que viene para analizar el onboarding
- #DPA-1733 
	- Generando en accounts-adapter y detectando algunos casos más, que tendré que mover al Reflector

==========

## 26/02/2024

- Echándole un vistazo a `products` para saber más sobre la solución con server-sent events que vamos a proponer para la parte del polling
	- Esto corre poca prisa
	- Hablamos con la gente de front y están de acuerdo bien con hacer polling, bien con utilizar SSE
	- Hay problemas utilizando SSE, ya que necesitamos algún tipo de persistencia intermedia entre el consumo de eventos y el manejo de los `SseEmitter`
- #DPA-1733 
	- Continúo con la prueba de encontrar todas las clases que definen eventos enviados desde un servicio (estoy utilizando ArchUnit)

## 27/02/2024

- #DPA-1733 
	- Dejo la herramienta en un estado bastante bueno. Doy por terminado esto
	- Empiezo a documentar lo que he hecho (tengo un borrador sin publicar)
- Me pongo con el tema de la incorporación de Julio
	- Abierto ticket con el acceso a los sistemas
	- Correo en borradores a Raquel, Morena, etc
		- Falta DNI y foto!!
	- Pendiente repasar el proceso de onboarding y mandarle las primeras reuniones con la gente (una vez tenga correo)
	- Documentar el proceso
		- Hecho
	- A la espera de que Nico diga "ok" en el ticket

## 28/02/2024

- Viendo con Carlos problemas con el generador de openapi
	- Cómo se distribuyen en interfaces las apis? (TODO)
- #DPA-1966 
	- Revisando las tareas, todas las que incluyen endpoints en rojo están ya siendo acometidas
- Onboarding de Julio
	- Convocado para la primera hora
		- Avisada la gente de LogNext
	- Avisado Nico. A la espera
	- Avisados Yair y David
		- Convocados

## 29/02/2024

- Documentando más cosas del onboarding
	- Hecho y terminadas las tareas del onboarding de Julio
- #DPA-1966 Seguimiento a la deprecación de endpoints de Mambú
	- Creo la DPA-2000 para cambiar el endpoint de currencies en sandbox
- #DPA-1733 
	- Documento todo lo que tengo en https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/4060348537/Adopting+Avro+and+Schema+Registry+for+async+integration
	- Miro la parte de la compatibilidad, etc


==========
## Pendientes

- Tema #DPA-1664 
	- En PayCards tienen que eliminar esos tests y añadir en su lugar los tests de arquitectura. Eliminar la dependencia con archunit
		- https://obkesp.atlassian.net/browse/PYC-768
		- Lo hicieron mal. Ahora están en ello otra vez
			- Hecho
		- Pendiente de mergear el código para dejar de depender de la librería antigua
	- Ir implantando lo de los convention tests

- Determinar una lista de temas de buenas prácticas y elegir cómo promoverlo entre los equipos, etc (sin fecha)
- Irse reuniendo con los equipos (1 on 1) (sin fecha)
- Reunirse con Ignacio Merlán y preguntar sobre qué ha pasado al intentar hacer continuous deployment (con Nuria también¿? ->> si)
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY
	- Abrir el melón del WoW

## Seguimiento

- Hacer seguimiento de los champion roles (due: 10/11)
- Tema de los endpoints de Mambú y su deprecación
## One Bank

| Tenant Code | Event Type                                                 | Template Names                                                                          | Topic |
|-------------|------------------------------------------------------------|-----------------------------------------------------------------------------------------|-------|
| FR          | mrn.event.obkcbsdev.streamingapi.savings_deposit              | streamingapi.transfers.inhouse.deposit, streamingapi.transfers.groups.inhouse.deposit         | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| FR          | mrn.event.obkcbsdev.streamingapi.deposit_account_created      | streamingapi.transfers.account.created, streamingapi.transfers.groups.account.created         | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| FR          | mrn.event.obkcbsdev.streamingapi.savings_withdrawal           | streamingapi.transfers.withdrawal, streamingapi.transfers.groups.withdrawal, streamingapi.transfers.inhouse.transfer, streamingapi.transfers.groups.inhouse.transfer   | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| FR          | mrn.event.obkcbsdev.streamingapi.payment_order_activity       | streamingapi.transfers.payment                                                             | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| FR          | mrn.event.obkcbsdev.streamingapi.collection_order_activity    | streamingapi.transfers.collection                                                          | onbaa.dev.transfers.direct-debit-mambu-streamingapi.prv |
| ES          | mrn.event.obkcbsdevsp.streamingapi.savings_deposit            | streamingapi.transfers.inhouse.deposit, streamingapi.transfers.groups.inhouse.deposit         | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| ES          | mrn.event.obkcbsdevsp.streamingapi.deposit_account_created    | streamingapi.transfers.account.created, streamingapi.transfers.groups.account.created         | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| ES          | mrn.event.obkcbsdevsp.streamingapi.savings_withdrawal         | streamingapi.transfers.withdrawal, streamingapi.transfers.groups.withdrawal, streamingapi.transfers.inhouse.transfer, streamingapi.transfers.groups.inhouse.transfer   | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| ES          | mrn.event.obkcbsdevsp.streamingapi.payment_order_activity     | streamingapi.transfers.payment                                                             | onbaa.dev.transfers.transfers-mambu-streamingapi.prv |
| ES          | mrn.event.obkcbsdevsp.streamingapi.collection_order_activity  | streamingapi.transfers.collection                                                          | onbaa.dev.transfers.direct-debit-mambu-streamingapi.prv |


## OBES

### Configuración `ORANGEBANK_BOOT_CBS`

| Event Type | Template Names | Entity ID | Entity Name | Partition ID | Topic |
|------------|----------------|-----------|-------------|--------------|-------|
| mrn.event.${orangebank.mambu.tenant}.streaming-api.savings_deposit | streaming-api.transfers.inhouse.deposit | transactionId | cbsTransferInhouseDeposit | transactionId | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.savings_withdrawal | streaming-api.transfers.withdrawal, streaming-api.transfers.inhouse.transfer | transactionId | cbsTransferWithdrawal, cbsTransferTransfer | transactionId | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.savings_created | streaming-api.transfers.account.created | accountId | cbsTransferAccountCreated | accountId | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.payment_order_activity | streaming-api.transfers.payment | transactionId | cbsTransferPayment | creditorAccountIban | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.collection_order_activity | streaming-api.transfers.collection | transactionId | cbsTransferCollection | creditorAccountIban | obes.transfers.direct-debit-mambu-streaming-api.prv |

### Configuración `ORANGEBANK_MAMBU`

| Event Type | Template Names | Entity ID | Entity Name | Partition ID | Topic |
|------------|----------------|-----------|-------------|--------------|-------|
| mrn.event.${orangebank.mambu.tenant}.streaming-api.savings_deposit | streaming-api.transfers.inhouse.deposit | transactionId | cbsTransferInhouseDeposit | transactionId | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.savings_withdrawal | streaming-api.transfers.withdrawal, streaming-api.transfers.inhouse.transfer | transactionId | cbsTransferWithdrawal, cbsTransferTransfer | transactionId | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.savings_created | streaming-api.transfers.account.created | accountId | cbsTransferAccountCreated | accountId | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.payment_order_activity | streaming-api.transfers.payment | transactionId | cbsTransferPayment | creditorAccountIban | obes.transfers.transfers-mambu-streaming-api.prv |
| mrn.event.${orangebank.mambu.tenant}.streaming-api.collection_order_activity | streaming-api.transfers.collection | transactionId | cbsTransferCollection | creditorAccountIban | obes.transfers.direct-debit-mambu-streaming-api.prv |

## 01/04/2024

- R: Cancelación de clientes - Daily
	- Nada en concreto. Están generando un event storming con las acciones pendientes para la cancelación de clientes
- R: Daily
	- Javi dice que tenemos un consumidor al que le puedes configurar errores para que saque cosas por la DLT
- R: Reunión de seguimiento - primer mes - Julio Martínez
	- Todo OK
- #DPA-1997 
	- Sigo intentando conectarme con el kafka-cli, pero no es posible hacerlo
		- Pregunto a Juanan, a ver si me puede echar una mano
			- Hecho! Hemos tenido que cambiar el archivo **consumer.properties** a otro que se encuentra en **/home/user/kafka/consumer.properties**
			- ✅ Edito el documento que tenemos sobre el kafka-cli
		- Parece que el topic está vacío --> Si. Lo está
			- Consumo mensajes del topic normal y me encuentro con este error: `Error while fetching metadata with correlation id XX : {messages_config_created.sandbox=UNKNOWN_TOPIC_OR_PARTITION} (org.apache.kafka.clients.NetworkClient)`
			- Era un error con el nombre del topic. Me pongo a consumir y consumo 1 mensaje de una prueba que hizo Javi hace no mucho
		- Investigar el consumidor este que da errores en el consumo y lo manda a la DLT
			- Lo encuentro y lo configuro. Tengo errores porque los valores numéricos tienen que ir entre comillas simples
		- Levanto `sandbox` en el entorno de desarrollo con la configuración del consumidor que da errores a "100". Lo confirmo en los logs
			- No lo consigo en Kibana. Lo miro con `kubectl logs`
		- Tengo que llamar al API de sandbox para generar un mensaje que se vaya a la DLT y confirmarlo
			- Hay que hacerlo utilizando un túnel! (https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/914817046/Runbook+How+to+call+internal+endpoints+from+local)
			- 🚫 La VPN falla y no soy capaz de reconectar
				- Conecto a la de backup!
			- No sé llamar a un endpoint directamente en el entorno de DEV
				- Consigo llamar utilizando un túnel
				- Necesito poner un header de autorización
					- Creo un token utilizando el jwt generator. Como UUID pongo uno inventado y pongo el permiso que dice la anotación del controller
				- Lo consigo!! He enviado un evento a la DLT
					- partición: 0
					- offset: 745
			- ✅ Compruebo que ejecuto el `reprocess-event-batch` y termina correctamente. Verifico que el evento se consume correctamente desde el topic de recovery
			- ❗Ojo no olvidarse de devolver la configuración de "consumir sin errores" al sandbox
- Tema permisos del equipo de Salesforce en Confluence
	- Le pido a Esther de Prado que desbloquee el ticket -> https://obkesp.atlassian.net/browse/OBS-46355
		- Hecho!
	- Tiene que contestar Pedro Pizarro
	- ✅ Hecho! Le pido a Alberto Puerto que confirme

## 02/04/2024

- #DPA-1997 
	- ✅ Devuelvo el `sandbox` al ratio normal de errores en el consumidor correspondiente
	- ✅ Despliego la `1.10.0` del `reprocess-event-batch` en INT
	- ✅ Despliego la `1.10.0` del `reprocess-event-batch` en PRE
	- 🚫 Para desplegar en PRO hay que pasar por la RT
		- Solicitado acceso al canal de desplieguies. En cuanto me lo den tengo que entrar a la tarjeta y asignarmela.
- #DPA-1966 
	- Confirmo que todas las APIs que van a desaparecer están migradas a la v2 (o deprecadas en el caso de las que ya no se usan)
	- ⚡ Le paso la info a Diego Almazán y quedo a la espera de que convoque una reunión para hablar con los afectados
		- ✅ La reunión está convocada
- Me pongo a ayudar a Ivan, que anda perdido con lo del `sandbox`
	- Que Andrei se eche un ojo al `sandbox`, para ver cómo funciona
	- El Jueves lo hablamos, que vamos a estar todos por la oficina
- #DPA-1995: SecurityAsyncConfigurationIT fails if it is the first IT to be executed
	- Reproduzco el bug
	- Comprendo lo que está haciendo el test
	- Debería comprender el mecanismo que hace que los contextos se limpien

## 03/04/2024

- R: "Daily"
	- Hablamos sobre la generación de código a partir de OpenAPI. Al final creamos la tarea #DPA-2036:  (openapi generator) PoC con revolving-loans-products
- #DPA-1995 
	- Tratando de comprender el sistema que limpia los contextos
	- Me vuelvo loco tratando de depurar
		- 🚫 No consigo depurar el objeto `ThreadLocal` que va debajo de todo
		- Me monto una suite para probar cómodamente desde IntelliJ
		- Descubro que
			- En el caso que funciona, el hilo `SecurityTaskExecutorThread-1` hace varios `set` del contexto en la clase `InheritableThreadLocalSecurityContextHolderStrategy`
			- En el caso donde no funciona, sólo hace un get
		- ⚡ Descubrir por qué ocurre esto. Tengo las trazas en dos pestañas diferentes del Sublime

## 04/04/2024

- #DPA-1995 
	- Me da tiempo a depurar un poco más
- R: Townhall
- Por la tarde no hacemos nada (no hay oficina)

## 05/04/2024

- David no puede acceder a este espacio de Confluence: https://obkesp.atlassian.net/wiki/spaces/PYC/overview
	- ⭕ Yo tampoco puedo. Le pregunto a Rafa de quién es este espacio
		- La idea es que pertenece a todo el equipo. A Rafa le parece bien que tenga acceso todo el equipo de paycards
		- ⚡Abrir el ticket para todo el equipo de Paycards
	- La idea sería acceso de lectura para todo el mundo y de edición para la gente de paycards
- R: Daily - Weekly
- R: Proceso de definición funcional
	- Jose Manuel nos pasa una retrospectiva que hizo Autentia del proyecto allá por 2019 y un documento con un ejemplo de matriz RACI+F
		- https://orangebankes-my.sharepoint.com/:b:/g/personal/jm_sanchez_ext_orangebank_es/EXdcfuEAhN1Kj3Ecnpl5p1YBWRr26mPkwIJhytDW8VrVyQ?e=Q8SPBl
		- https://orangebankes-my.sharepoint.com/:w:/r/personal/jm_sanchez_ext_orangebank_es/Documents/T%C3%A9cnicas%20%C3%A1giles.docx?d=we1b668d7a29940fba4c04c2a565ae543&csf=1&web=1&e=e8gPLw
	- Nos parece que Ivan Morales debe liderar este proceso y nos vamos a reunir con él
		- ⚡Nico tiene antes que hablar con Carmina
- #DPA-1995 
	- Sigo depurando un poco más
		- La diferencia es que en el hilo que funciona hay algún tipo de actividad de copia de contextos que tiene lugar en los siguientes métodos, que en el orden que no funciona nunca se ejecutan
			- `DelegatingSecurityContextRunnable#setSecurityContextHolderStrategy`
			- `DelegatingSecurityContextRunnable#run`

==========

## 08/04/2024

- R: Deprecado apis v1 Mambu
	- ⚡ 1 de Septiembre para que empiecen a decomisionar en entorno sandbox. Avisaremos si terminamos antes. Deberíamos no tener problemas.
- #DPA-1995 
	- Hipótesis: Al primer test que se ejecuta no le da tiempo a cambiar la estrategia del `SecurityContextHolder` desde `ThreadLocal` a `InheritableThreadLocal` porque el cambio lo hacemos en el `BootResourceServerConfiguration`
		- Si lo hace, pero el `DelegatingSecurityContextAsyncTaskExecutor` que se crea cuando aún no hemos configurado correctamente la estrategia sobreescribe la propiedad en el `DelegatingSecurityContextRunnable`, que pasa a no copiar los contextos
	- Nueva hipótesis:
		- En el arranque hay un momento en el que la estrategia del `SecurityContextHolder` no es inheritable. En ese momento se crea el TaskExecutor, que sobreescribe a lo que más adelante haya definido a nivel global en cada runnable que crea
		- Cuando este test no es el primero, el `AsyncTaskExecutor` toma la variable del `SecurityContextHolder` (que se mantiene entre tests) y se inicializa correctamente.
		- Si esto es cierto, **el contexto de seguridad no se está propagando correctamente**

## 09/04/2024

- Vuelvo a escribir un mensaje en el chat con lo de los permisos de Confluence
- #DPA-1995 
	- Consigo modificar el test de integración para que falle siempre ante lo que he corregido, sin importar el orden
	- Subo el código a master
	- Me lío con el script de tests automáticos y me pongo a probar

## 10/04/2024

- #DPA-1995 
	- Sigo haciendo pruebas, y certifico que funciona en una buena batería de proyectos
	- Añado la resolución a las release notes. Terminado
- #DPA-1733 
	- Hay que ver cómo continuamos esto basándonos un poco en lo que se ha hecho en la tarea equivalente para open api
	- Carlos en #DPA-2036 está haciendo una PoC con `revolving-loans-products`
		- Generando durante el proceso de construcción con el plugin `openapi-generator-maven-plugin`
		- Editando el `openapi.yml` para adecuarse a lo que se necesita desde el plugin
		- Tocando los typemappings para que ciertas clases se generen como nosotros queremos
		- Adaptando los controllers y los feign clients
	- ¿Qué podemos hacer?
		- Hay que desarrollar
			- Un starter rudimentario. Para el consumo y para la producción.
			- Un tile para los tests
			- Terminar la herramienta que genera esquemas a partir de clases
		- Desplegar un schema registry en dev como si fuera un nuevo servicio
			- Preparar una colección de postman para interactuar con él
		- Necesitamos dos servicios
			- Productor
			- Consumidor
		- Usar la herramienta para generar los esquemas en AVSC
		- Añadirles el `avro-maven-plugin` para que se ejecute durante el proceso de construcción y genere las subclases de `SpecificRecord`
		- Adaptar el producer y el consumer
		- Adaptar `docker-compose` y la configuración para incluir la configuración necesaria
		- Editar el `asyncapi.yml` para que enlace con los esquemas avsc
			- Desactivar de momento la documentación
		- Registrar los esquemas a mano usando Postman (puede usarse un plugin pero esto no lo quieres hacer cada vez que construyas sino cada vez que despliegues)

## 11/04/2024

- R: Julio Martinez - Project status
- #DPA-2003: user.id no informado correctamente para llamadas impersonadas
	- En los casos en los que hay llamadas impersonadas, se está metiendo el user.Impersonation.Id (correo del agente) dentro del campo user.id (uuid del cliente)
	- Ejemplo: servicio "people"; endpoint: "/me"
	- Trazas: "SERVICE_INBOUND_REQUEST" y "SERVICE_INBOUND_RESPONSE"

==========

## 15/04/2024

- R: Revisión PoC avro + schema registry
	- Dejamos fuera del scope algunas tareas no esenciales
	- Asunto de no poder sobrescribir el paquete derivado del namespace del avsc
		- Se soluciona utilizando namespaces que cuelguen de un paquete especial determinado por nosotros. Estilo "com.xxxbank.schema.dominio"
	- Resultado: #DPA-2046: Implement schema registry + avro in dev environment
- #DPA-2003: Tratando de reproducir el bug en local
	- Consigo arrancar el servicio en local
		- ✅ Le paso el comando: `mvn spring-boot:run -Dspring-boot.run.profiles=local -Dspring-boot.run.arguments="--spring.kafka.bootstrap-servers=localhost:31111"`
	- ⭕ Falla seguramente porque no le he seteado el JWKS que comprueba la firma del token
		- Consigo llamar al servicio dejando el JWKS por defecto y generando un token con este código:
```
			final UUID id = UUID.randomUUID();  
			String token = new AuthenticatedUserTokenBuilder()  
			.withOffsetExpiredHours(87600)  
			.withSubject(id)  
			.withOwner(id, "Get person info")  
			.buildToken();  
			System.out.println("token = " + token);
```

- Continúo
	- 🚫 Works on my machine ™️
		- Encuentro que en local las `SERVICE_INBOUND_REQUEST` no trazan nada
		- Las `SERVICE_INBOUND_REQUEST` trazan correctamente el `user.id` con el id del usuario y el `user.Impersonation.Id` con el correo del agente

## 16/04/2024

- #DPA-2003 : Estoy atascado. Javi me ha sugerido algunas cosas
	- Mirar si ese error se repite en entornos previos
		- ✅ Si, de hecho ayer detecté el error en el entorno de DEV (el índice es "mls-logs-development-development")
	- Mirar los logs con kubectl logs (en dev)
		- ✅ En los logs de dev con `kubectl logs` también aparece el fallo
	- ✅ Hipótesis: Hay un problema con el token que se le está mandando
		- Hago peticiones a dev y el contenido de `user.id` y `user.Impersonation.Id` está bien
		- Veo que el problema parece estar en las llamadas desde Salesforce
			- Todas las llamadas con el problema en el último mes tienen un `user_agent.original` con valor `SFDC-Callout/60.0`
			- Hay diversos endpoints
	- Le paso el bug a Morgan
		- Tiene pinta de que el problema está en el `identity-provider`. clase `com.orangebank.identity.provider.oauth2.web.provider.CrmImpersonationTokenProvider#101`

## 17/04/2024

- #DPA-2023: Implantar los convention tests en el código de los squads
	- ✅ Suelto chapa en el chat de backend
- #DPA-1743: Integrate the MapStruct library in place of Spring's converter framework
	- Me doy cuenta de que Misael no metió la dependencia de Lombok con el scope a provided
		- ✅ Pruebo que ob-boot compila correctamente quitándolo
		- ✅ Subir la versión de la dependencia
		- ✅ Probar algún proyecto que use Lombok y esté ya en la `2.16.0`
- #DPA-1916: Revisar el soporte de auto configuraciones de los componentes de arquitectura
	- Me llama Santi porque los tests de convención no funcionan así
		- ✅ Echar un vistazo a ver qué alternativas tenemos con esto
			- Al final Santi lo arregla utilizando `@EnableAutoConfiguration`
			- Yo sólo consigo "arreglarlo" metiendo una clase con `@SpringBootApplication` dentro del proyecto (realmente lo que he "descubierto" yo hace lo mismo)
			- Podemos tener problemas si la gente comienza a añadir cosas en sus clases `Application`. Deberíamos vigilar esto.

## 18/04/2024

- #DPA-1743
	- ✅ Refactor de la dependencia de Lombok
		- La dependencia nos la estábamos trayendo desde `orangebank-boot-test` de forma transitiva a la que tiene el `mountebank-client`
		- Muevo esto a `orangebank-boot-parent` (proyectos) y a `orangebank-boot-starters`, `orangebank-boot-libs` (arquitectura)
		- ⚡ Hablar de ello en la daily del lunes.
	- Añadir MapStruct y la integración con Lombok en la librería de arquitectura
	- Metiendo mapstruct en `sandbox`

## 19/04/2024

- #DPA-1743 
	- Termino casi de eliminar el uso de `ConversionService` dentro de `sandbox`
	- Añado la dependencia a `easy-random` y la utilizo
	- Termino de adaptar los tests a `easy-random` y `assertJ`

==========

## 22/04/2024

- #DPA-1743 
	- ✅ Subida la dependencia de `easy-random` a `orangebank-boot-test`
	- Termino de adaptar `sandbox`
		- ⭕ No funciona el pipeline
		- ✅ Si!
	- ✅ Añado páginas de documentación y release notes sobre `mapstruct` y `easy-random`

## 23/04/2024

- #DPA-2049: Microservicio que no utiliza el starter-events-journal falla al utilizar ob-boot-convention test
	- xxx

## 24/04/2024

- #DPA-2046: Implement schema registry + avro in dev environment

## 25/04/2024

- ✅ Curso de Python y ejercicios
- #DPA-2046
	- ✅ Primer despliegue del servicio
	- Tratando de acceder a los logs
		- ✅ Conseguido! `kubectl logs -n platform-global-services poc-schema-registry-644c5884f6-frrkv -c poc-schema-registry -f`
	- ✅ Consigo desplegar el servicio. En principio correctamente

## 26/04/2024

- ✅ Curso de Python: numpy y pandas
- #DPA-2046 
	- ✅ Me creo el RunBook para conectarme a DEV
	- Conecto pero me da `ERROR 502: Bad Gateway`
		- Puede ser que no he mapeado bien los puertos?
		- Puede ser que no he seteado bien el host en la config del schema registry?

==========

## 27/04/2024

- ✅ Curso de py, pandas
- #DPA-2046 
	- ✅ Consigo acceder al schema registry sin hacer el doble tunel
	- ✅ Busco una colección de postman y la subo a Confluence
	- ✅ Miro en la documentación para ver la seguridad de ese API
		- Certificado y basic en la versión no comercial
		- Confluent platform : OAuth, Roles, etc

## 28/04/2024

- Me leo el ADR https://obkesp.atlassian.net/wiki/spaces/DELIVARCH/pages/4129751089/Context+propagation+in+multi-thread+models y su correspondiente tarea #DPA-2047
- #DPA-2046 
	- Investigando el `kafka-schema-registry-maven-plugin`
		- No
	- Me bajo `revolving-loans-statements-batch`
		- Subo versión a la última de arquitectura



==========
## Pendientes

- ❗❗ Darle continuidad a lo del schema registry y a lo del OpenAPI
	- En caso de que el proyecto tenga la continuidad asegurada
	- La PoC en local ya está hecha. Merece la pena una PoC en DEV?
		- Consiste en desplegar un schema registry "de estraperlo" como un microservicio y desplegar la PoC. ¿Merece la pena?
	- Ya está enviada la convocatoria para el Lunes 15
		- Ideas con qué continuar añadidas a la convocatoria de la reunión
- Tema #DPA-1664 
	- ⚡ Ir implantando lo de los convention tests
- Hablar de dónde establecer las dependencias con el ejemplo de Lombok
	- 📅 **Lunes 22 de Abril - Daily**

## Seguimiento

- ⚡ Tema de los permisos en confluence
	- 📆 El **4 de Abril** vuelve Julián de vacaciones. Seguimos empujando con esto
	- El 9 de Abril vuelvo a preguntar en el chat
- Tema #DPA-1966 
	- ⭕ A la espera de que Diego Almazán convoque una reunión con los afectados (hay que migrarlo antes del freeze de verano)
	- 📆 La fecha de decomisionado de los entornos pasa a ser el **1 de Septiembre**. Hemos de comunicarlo si terminamos antes.
	- 📅 Se atrasa esto a Q1 de 2024
- ⚡ Mejoras en el way of working
	- Nico va a hablar con Carmina sobre nombrar responsable de todo esto a Ivan Morales
	- Cuando nos de el OK hay que juntarse con él para hablarle de todo lo que hemos pensado al respecto

## Planes

- 💡 Hacer 1 on 1 con la gente del equipo de backend
	- En caso de que el proyecto tenga continuidad asegurada
- 💡♨️ Dar pasos hacia el continuous deployment
	- https://obkesp.atlassian.net/wiki/spaces/DEV/pages/1683193870/CONTINUOUS+DELIVERY


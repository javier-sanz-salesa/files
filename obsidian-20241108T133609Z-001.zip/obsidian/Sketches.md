## Cambios en la imagen base para M1

```
<plugin>  
  <groupId>com.google.cloud.tools</groupId>  
  <artifactId>jib-maven-plugin</artifactId>  
  <configuration>  
    <from>  
      <image>docker://java-base-image-arm:latest</image>  
    </from>  
  </configuration>  
</plugin>
```
